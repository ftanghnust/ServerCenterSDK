/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 11/2/2015 8:32:16 PM
 * *******************************************************/
using System;
using System.Collections.Generic;

namespace Frxs.Erp.ServiceCenter.Product.SDK
{
    /// <summary>
    /// �����ֵ��࣬����ǩ��
    /// </summary>
    internal class ApiDictionary : SortedDictionary<string, string>
    {
        /// <summary>
        /// 
        /// </summary>
        private const string DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

        /// <summary>
        /// 
        /// </summary>
        public ApiDictionary() { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dictionary"></param>
        public ApiDictionary(IDictionary<string, string> dictionary)
            : base(dictionary)
        { }

        /// <summary>
        /// ����һ���µļ�ֵ�ԡ��ռ����߿�ֵ�ļ�ֵ�Խ��ᱻ���ԡ�
        /// </summary>
        /// <param name="key">������</param>
        /// <param name="value">����Ӧ��ֵ��Ŀǰ֧�֣�string, int, long, double, bool, DateTime����</param>
        public void Add(string key, object value)
        {
            string strValue;

            if (value == null)
            {
                strValue = null;
            }
            else if (value is string)
            {
                strValue = (string)value;
            }
            else if (value is Nullable<DateTime>)
            {
                Nullable<DateTime> dateTime = value as Nullable<DateTime>;
                strValue = dateTime.Value.ToString(DATE_TIME_FORMAT);
            }
            else if (value is Nullable<int>)
            {
                strValue = (value as Nullable<int>).Value.ToString();
            }
            else if (value is Nullable<long>)
            {
                strValue = (value as Nullable<long>).Value.ToString();
            }
            else if (value is Nullable<double>)
            {
                strValue = (value as Nullable<double>).Value.ToString();
            }
            else if (value is Nullable<bool>)
            {
                strValue = (value as Nullable<bool>).Value.ToString().ToLower();
            }
            else
            {
                strValue = value.ToString();
            }

            this.Add(key, strValue);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public new void Add(string key, string value)
        {
            if (!string.IsNullOrEmpty(key) && !string.IsNullOrEmpty(value))
            {
                base.Add(key, value);
            }
        }
    }
}
