/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.ServiceCenter.Api.Core
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:API.ServerTime.Get
* ActionType:Frxs.ServiceCenter.Api.Core.Actions.ServerTimeGetActionV11
* AllowAnonymous:True
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:API.ServerTime.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.ServiceCenter.Api.Core.NullRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.String
* Route:
* UnloadCacheKeys:
* Version:1.1
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class APIServerTimeGetRequest : RequestBase<Resp.APIServerTimeGetResp> 
	{
		/// <summary>
		/// ���ýӿ����ƣ�API.ServerTime.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "API.ServerTime.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.UserId,this.UserName }.ToJson();
		}

	}
}