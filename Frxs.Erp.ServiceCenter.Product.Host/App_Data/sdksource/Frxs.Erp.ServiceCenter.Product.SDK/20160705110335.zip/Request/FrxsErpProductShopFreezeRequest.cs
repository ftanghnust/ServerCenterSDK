/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Shop.Freeze
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ResponseDto.Shop.ShopFreezeAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Shop.Freeze
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ShopFreezeRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// �����ⶳ�ŵ�
	/// </summary>
	public class FrxsErpProductShopFreezeRequest : RequestBase<Resp.FrxsErpProductShopFreezeResp> 
	{
		/// <summary>
		/// �ŵ�ID ��������ʱ��,�ŷָ�
		/// </summary>
		public string ShopID { get; set; }
		/// <summary>
		/// ״̬(1:����;0:����)
		/// </summary>
		public int Status { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Shop.Freeze
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Shop.Freeze";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ShopID,this.Status,this.UserId,this.UserName }.ToJson();
		}

	}
}