/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Products.Attributes.Update
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsAttributesUpdateAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Products.Attributes.Update
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsAttributesUpdateRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.NullResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ������Ʒ�������
	/// </summary>
	public class FrxsErpProductProductsAttributesUpdateRequest : RequestBase<ResponseBase> 
	{
		/// <summary>
		/// ��ƷID
		/// </summary>
		public int ProductId { get; set; }
		/// <summary>
		/// ������Լ���
		/// </summary>
		public ICollection<ProductsAttribute> ProductsAttributes { get; set; }
		/// <summary>
		/// ��Ʒ���ͼƬ
		/// </summary>
		public AttributesPicture ProductsAttributesPicture { get; set; }
		/// <summary>
		/// �Ƿ����
		/// </summary>
		public int IsMutiAttribute { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Products.Attributes.Update
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Products.Attributes.Update";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ProductId,
				this.ProductsAttributes,
				this.ProductsAttributesPicture,
				this.IsMutiAttribute,
				this.UserId,
				this.UserName }.ToJson();
		}

		/// <summary>
		/// �ϴ��Ĺ�����Լ�ֵ��
		/// </summary>
		public class ProductsAttribute
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int AttributeId { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string AttributeName { get; set; }
			/// <summary>
			/// ����ֵID
			/// </summary>
			public int ValuesId { get; set; }
			/// <summary>
			/// ���Ե�ֵ
			/// </summary>
			public string ValueStr { get; set; }
		}

		/// <summary>
		/// �������ͼ
		/// </summary>
		public class AttributesPicture
		{
			/// <summary>
			/// ԭʼͼ
			/// </summary>
			public string ImageUrlOrg { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ImageUrl400X400 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ImageUrl200X200 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ImageUrl120X120 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ImageUrl60X60 { get; set; }
		}

	}
}