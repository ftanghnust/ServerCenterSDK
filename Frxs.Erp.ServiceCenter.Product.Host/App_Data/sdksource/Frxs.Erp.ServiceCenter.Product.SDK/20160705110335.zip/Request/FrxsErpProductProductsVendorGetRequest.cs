/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ProductsVendor.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsVendorGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ProductsVendor.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsVendorGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.ProductsVendor]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��ȡ��Ӧ����Ʒ��ϵ��������ҳ�Ͳ���ҳ���֣�
	/// </summary>
	public class FrxsErpProductProductsVendorGetRequest : RequestBase<Resp.FrxsErpProductProductsVendorGetResp> 
	{
		/// <summary>
		/// �Ƿ��ҳ��ѯ(Ϊ1��ʾ��ҳ��Ϊ0��NULL ����ҳ)
		/// </summary>
		public int? IsPage { get; set; }
		/// <summary>
		/// ����ID
		/// </summary>
		public long? ID { get; set; }
		/// <summary>
		/// �ֿ�ID
		/// </summary>
		public int? WID { get; set; }
		/// <summary>
		/// ��ƷID(product.ProductID)
		/// </summary>
		public int? ProductId { get; set; }
		/// <summary>
		/// ��Ʒ����Ӧ��
		/// </summary>
		public int? VendorID { get; set; }
		/// <summary>
		/// ��浥λ
		/// </summary>
		public string Unit { get; set; }
		/// <summary>
		/// ��浥λ�ɹ��۸�
		/// </summary>
		public decimal? BuyPrice { get; set; }
		/// <summary>
		/// �Ƿ�Ϊ����Ӧ��(0:����;1:��)
		/// </summary>
		public int? IsMaster { get; set; }
		/// <summary>
		/// ��浥λ���½���
		/// </summary>
		public double? LastBuyPrice { get; set; }
		/// <summary>
		/// ���²ɹ����ʱ��
		/// </summary>
		public DateTime? LastBuyTime { get; set; }
		/// <summary>
		/// ��ѯ�ؼ��֣����롢���롢����
		/// </summary>
		public string KeyWord { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.ProductsVendor.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.ProductsVendor.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.IsPage,
				this.ID,
				this.WID,
				this.ProductId,
				this.VendorID,
				this.Unit,
				this.BuyPrice,
				this.IsMaster,
				this.LastBuyPrice,
				this.LastBuyTime,
				this.KeyWord,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}