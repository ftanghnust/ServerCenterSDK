/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Attributes.GetList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.AttributesGetListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Attributes.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.AttributesGetListAction+AttributesGetListRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.Attributes]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ���Ի�ȡ
	/// </summary>
	public class FrxsErpProductAttributesGetListRequest : RequestBase<Resp.FrxsErpProductAttributesGetListResp> 
	{
		/// <summary>
		/// �������
		/// </summary>
		public string AttributeName { get; set; }
		/// <summary>
		/// ���ֵ
		/// </summary>
		public string ValueStr { get; set; }
		/// <summary>
		/// ��ǰҳ(Ĭ��1)
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// ��ҳ��С��Ĭ��10��
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Attributes.GetList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Attributes.GetList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.AttributeName,
				this.ValueStr,
				this.PageIndex,
				this.PageSize,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}