/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.SysDictDetail.GetList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.SysDictDetailGetListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.SysDictDetail.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.SysDictDetailGetListAction+SysDictDetailGetListRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.IList`1[Frxs.Erp.ServiceCenter.Product.Model.SysDictDetail]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��ȡ��Ӧ���б�
	/// </summary>
	public class FrxsErpProductSysDictDetailGetListRequest : RequestBase<Resp.FrxsErpProductSysDictDetailGetListResp> 
	{
		/// <summary>
		/// 
		/// </summary>
		public string dictCode { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.SysDictDetail.GetList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.SysDictDetail.GetList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.dictCode,this.UserId,this.UserName }.ToJson();
		}

	}
}