/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ProductsDescriptionAndPicture.AddOrEdit
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsDescriptionAndPictureAddOrEditAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ProductsDescriptionAndPicture.AddOrEdit
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsDescriptionAndPictureAddOrEditRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.NullResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ���������޸���Ʒ����
	/// </summary>
	public class FrxsErpProductProductsDescriptionAndPictureAddOrEditRequest : RequestBase<ResponseBase> 
	{
		/// <summary>
		/// ĸ��Ʒ���
		/// </summary>
		public int ProductId { get; set; }
		/// <summary>
		/// ĸ��Ʒ���
		/// </summary>
		public int BaseProductId { get; set; }
		/// <summary>
		/// ��Ʒ����
		/// </summary>
		public string Description { get; set; }
		/// <summary>
		/// ������Ʒͼ�������б�
		/// </summary>
		public IList<ProductsDescriptionPictureRequestDto> ProductsDescriptionPicture { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.ProductsDescriptionAndPicture.AddOrEdit
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.ProductsDescriptionAndPicture.AddOrEdit";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ProductId,
				this.BaseProductId,
				this.Description,
				this.ProductsDescriptionPicture,
				this.UserId,
				this.UserName }.ToJson();
		}

		/// <summary>
		/// 
		/// </summary>
		public class ProductsDescriptionPictureRequestDto
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int ID { get; set; }
			/// <summary>
			/// ��Ʒĸ��ID
			/// </summary>
			public int BaseProductId { get; set; }
			/// <summary>
			/// ԭͼ·��
			/// </summary>
			public string ImageUrlOrg { get; set; }
			/// <summary>
			/// zipΪ400*400��ͼ·��
			/// </summary>
			public string ImageUrl400x400 { get; set; }
			/// <summary>
			/// zipΪ200*200��ͼ·��
			/// </summary>
			public string ImageUrl200x200 { get; set; }
			/// <summary>
			/// zipΪ120*120��ͼ·��
			/// </summary>
			public string ImageUrl120x120 { get; set; }
			/// <summary>
			/// zipΪ60*60��ͼ·��
			/// </summary>
			public string ImageUrl60x60 { get; set; }
			/// <summary>
			/// ����(1,2,3..)
			/// </summary>
			public int OrderNumber { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public string CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int UserId { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string UserName { get; set; }
		}

	}
}