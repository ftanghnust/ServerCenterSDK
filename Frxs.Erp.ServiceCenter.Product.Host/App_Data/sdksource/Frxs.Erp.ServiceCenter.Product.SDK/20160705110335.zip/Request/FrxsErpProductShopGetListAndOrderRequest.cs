/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Shop.GetListAndOrder
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ResponseDto.Shop.ShopGetListAndOrderAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Shop.GetListAndOrder
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ShopGetListAndOrderRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.IList`1[Frxs.Erp.ServiceCenter.Product.Model.ShopExt]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��ȡ�ܲ���̨�ŵ���Ϣ����(�����ŵ�)
	/// </summary>
	public class FrxsErpProductShopGetListAndOrderRequest : RequestBase<Resp.FrxsErpProductShopGetListAndOrderResp> 
	{
		/// <summary>
		/// ��������
		/// </summary>
		public string SearchDate { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int? ShopType { get; set; }
		/// <summary>
		/// �Ƿ��µ���1Ϊ�µ���0Ϊ��
		/// </summary>
		public string IsOrder { get; set; }
		/// <summary>
		/// �����ֿ�
		/// </summary>
		public string WID { get; set; }
		/// <summary>
		/// ��·ID WarehouseLineShop.LineID
		/// </summary>
		public string LineId { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Shop.GetListAndOrder
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Shop.GetListAndOrder";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.SearchDate,
				this.ShopType,
				this.IsOrder,
				this.WID,
				this.LineId,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}