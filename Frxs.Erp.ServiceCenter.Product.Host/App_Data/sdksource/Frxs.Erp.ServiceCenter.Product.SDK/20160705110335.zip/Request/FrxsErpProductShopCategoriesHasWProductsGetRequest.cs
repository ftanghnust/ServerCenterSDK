/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ShopCategories.HasWProducts.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ShopCategoriesHasWProductsGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ShopCategories.HasWProducts.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.ShopCategoriesHasWProductsGetAction+ShopCategoriesHasWProductGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Model.ShopCategories]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��ȡ�����вֿ���Ʒ����Ӫ����;�ڲֿ���û����Ʒ��Ϣ����Ӫ���಻���������
	/// </summary>
	public class FrxsErpProductShopCategoriesHasWProductsGetRequest : RequestBase<Resp.FrxsErpProductShopCategoriesHasWProductsGetResp> 
	{
		/// <summary>
		/// �ֿ�ID
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// �ŵ�ID
		/// </summary>
		public int ShopId { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.ShopCategories.HasWProducts.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.ShopCategories.HasWProducts.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,this.ShopId,this.UserId,this.UserName }.ToJson();
		}

	}
}