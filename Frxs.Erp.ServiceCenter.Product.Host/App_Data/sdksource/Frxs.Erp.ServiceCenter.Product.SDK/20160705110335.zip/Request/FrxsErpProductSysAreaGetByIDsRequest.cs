/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.SysArea.GetByIDs
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.SysAreaGetByIDsAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.SysArea.GetByIDs
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.SysAreaGetByIDsAction+SysAreaGetByIDsActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.IList`1[Frxs.Erp.ServiceCenter.Product.Model.SysArea]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ����ID���ϻ�ȡϵͳ��������Ϣ
	/// </summary>
	public class FrxsErpProductSysAreaGetByIDsRequest : RequestBase<Resp.FrxsErpProductSysAreaGetByIDsResp> 
	{
		/// <summary>
		/// ����ID����
		/// </summary>
		public List<int> Ids { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.SysArea.GetByIDs
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.SysArea.GetByIDs";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.Ids,this.UserId,this.UserName }.ToJson();
		}

	}
}