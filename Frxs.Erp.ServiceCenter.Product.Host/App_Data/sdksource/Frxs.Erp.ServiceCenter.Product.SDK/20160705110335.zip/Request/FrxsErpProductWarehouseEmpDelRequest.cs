/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WarehouseEmp.Del
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WarehouseEmp.WarehouseEmpDelAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WarehouseEmp.Del
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.WarehouseEmpDelRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductWarehouseEmpDelRequest : RequestBase<Resp.FrxsErpProductWarehouseEmpDelResp> 
	{
		/// <summary>
		/// �û����
		/// </summary>
		public string EmpID { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WarehouseEmp.Del
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WarehouseEmp.Del";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.EmpID,this.UserId,this.UserName }.ToJson();
		}

	}
}