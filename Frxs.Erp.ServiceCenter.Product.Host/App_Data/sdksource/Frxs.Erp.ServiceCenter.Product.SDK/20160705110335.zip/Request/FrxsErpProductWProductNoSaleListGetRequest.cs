/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProduct.NoSale.List.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductNoSaleListGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProduct.NoSale.List.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductNoSaleListGetAction+WProductNoSaleListGetRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.WProductNoSale]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// �ֿ���Ʒ�޹����� �б���ѯ
	/// </summary>
	public class FrxsErpProductWProductNoSaleListGetRequest : RequestBase<Resp.FrxsErpProductWProductNoSaleListGetResp> 
	{
		/// <summary>
		/// �ֿ�ID ����
		/// </summary>
		public int? WID { get; set; }
		/// <summary>
		/// ���ݺ� ����ID(WID + GUID)
		/// </summary>
		public string NoSaleID { get; set; }
		/// <summary>
		/// ��Ʒ����
		/// </summary>
		public string ProductName { get; set; }
		/// <summary>
		/// �����
		/// </summary>
		public string PromotionName { get; set; }
		/// <summary>
		/// ��Ʒ����
		/// </summary>
		public string BarCode { get; set; }
		/// <summary>
		/// ERP����
		/// </summary>
		public string SKU { get; set; }
		/// <summary>
		/// ����״̬  ״̬(0:δ�ύ;1:���ύ;2:(������Ч)�ѹ���/�ѿ�ʼ;3:��ͣ��)
		/// </summary>
		public int? Status { get; set; }
		/// <summary>
		/// ��Чʱ�� ��ʼʱ���(yyyy-MM-dd HH:mm:ss)
		/// </summary>
		public DateTime? BeginTimeFrom { get; set; }
		/// <summary>
		/// ��Чʱ�� ����ʱ���(yyyy-MM-dd HH:mm:ss)
		/// </summary>
		public DateTime? BeginTimeEnd { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WProduct.NoSale.List.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WProduct.NoSale.List.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.NoSaleID,
				this.ProductName,
				this.PromotionName,
				this.BarCode,
				this.SKU,
				this.Status,
				this.BeginTimeFrom,
				this.BeginTimeEnd,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}