/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Warehouse.Save
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.Warehouse.WarehouseSaveAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Warehouse.Save
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.WarehouseSaveRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// �����ֿ���Ϣ
	/// </summary>
	public class FrxsErpProductWarehouseSaveRequest : RequestBase<Resp.FrxsErpProductWarehouseSaveResp> 
	{
		/// <summary>
		/// �ֿ���(Ψһ)
		/// </summary>
		public string WCode { get; set; }
		/// <summary>
		/// �ֿ�����
		/// </summary>
		public string WName { get; set; }
		/// <summary>
		/// �ֿ⼶��(0:�ܲ�[Ԥ��];1:�ֿ�;2:�ֿ��ӻ�������/�˻�])
		/// </summary>
		public int WLevel { get; set; }
		/// <summary>
		/// �ӻ�������(0:�˻�;1:������;)
		/// </summary>
		public int WSubType { get; set; }
		/// <summary>
		/// ����ID
		/// </summary>
		public int ParentWID { get; set; }
		/// <summary>
		/// ��ϵ�绰
		/// </summary>
		public string WTel { get; set; }
		/// <summary>
		/// ��ϵ������
		/// </summary>
		public string WContact { get; set; }
		/// <summary>
		/// ʡ
		/// </summary>
		public int? ProvinceID { get; set; }
		/// <summary>
		/// ��
		/// </summary>
		public int? CityID { get; set; }
		/// <summary>
		/// ��
		/// </summary>
		public int? RegionID { get; set; }
		/// <summary>
		/// ��ַ
		/// </summary>
		public string WAddress { get; set; }
		/// <summary>
		/// ȫ�Ƶ�ַ
		/// </summary>
		public string WFullAddress { get; set; }
		/// <summary>
		/// 400�ͷ��绰
		/// </summary>
		public string WCustomerServiceTel { get; set; }
		/// <summary>
		/// �˻����绰
		/// </summary>
		public string THBTel { get; set; }
		/// <summary>
		/// �����ҵ绰
		/// </summary>
		public string CWTel { get; set; }
		/// <summary>
		/// ҵ����ѯ�绰1
		/// </summary>
		public string YW1Tel { get; set; }
		/// <summary>
		/// ҵ����ѯ�绰2
		/// </summary>
		public string YW2Tel { get; set; }
		/// <summary>
		/// ��ע
		/// </summary>
		public string Remark { get; set; }
		/// <summary>
		/// �Ƿ��ѱ�����(0:δ����;1���Ѷ���)
		/// </summary>
		public int IsFreeze { get; set; }
		/// <summary>
		/// �Ƿ��ѱ�ɾ��(0:δɾ��;1����ɾ��)
		/// </summary>
		public int IsDeleted { get; set; }
		/// <summary>
		/// ����ʱ��
		/// </summary>
		public DateTime CreateTime { get; set; }
		/// <summary>
		/// �����û� ID
		/// </summary>
		public int CreateUserID { get; set; }
		/// <summary>
		/// �����û�����
		/// </summary>
		public string CreateUserName { get; set; }
		/// <summary>
		/// �޸�ʱ��
		/// </summary>
		public DateTime ModityTime { get; set; }
		/// <summary>
		/// ����޸��û�ID
		/// </summary>
		public int ModityUserID { get; set; }
		/// <summary>
		/// ����޸��û�����
		/// </summary>
		public string ModityUserName { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Warehouse.Save
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Warehouse.Save";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WCode,
				this.WName,
				this.WLevel,
				this.WSubType,
				this.ParentWID,
				this.WTel,
				this.WContact,
				this.ProvinceID,
				this.CityID,
				this.RegionID,
				this.WAddress,
				this.WFullAddress,
				this.WCustomerServiceTel,
				this.THBTel,
				this.CWTel,
				this.YW1Tel,
				this.YW2Tel,
				this.Remark,
				this.IsFreeze,
				this.IsDeleted,
				this.CreateTime,
				this.CreateUserID,
				this.CreateUserName,
				this.ModityTime,
				this.ModityUserID,
				this.ModityUserName,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}