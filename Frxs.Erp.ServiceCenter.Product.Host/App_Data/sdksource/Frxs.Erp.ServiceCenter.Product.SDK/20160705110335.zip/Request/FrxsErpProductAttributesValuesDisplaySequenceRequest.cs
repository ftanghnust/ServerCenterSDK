/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.AttributesValues.DisplaySequence
* ActionType:Frxs.ServiceCenter.Product.Api.Actions.AttributesValuesDisplaySequenceAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.AttributesValues.DisplaySequence
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.ServiceCenter.Product.Api.Actions.AttributesValuesDisplaySequenceAction+AttributesValuesDisplaySequenceRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.NullResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductAttributesValuesDisplaySequenceRequest : RequestBase<ResponseBase> 
	{
		/// <summary>
		/// ����ID
		/// </summary>
		public int ValuesIdA { get; set; }
		/// <summary>
		/// ����ID
		/// </summary>
		public int ValuesIdB { get; set; }
		/// <summary>
		/// ����
		/// </summary>
		public int DisplaySequenceA { get; set; }
		/// <summary>
		/// ����
		/// </summary>
		public int DisplaySequenceB { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.AttributesValues.DisplaySequence
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.AttributesValues.DisplaySequence";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ValuesIdA,
				this.ValuesIdB,
				this.DisplaySequenceA,
				this.DisplaySequenceB,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}