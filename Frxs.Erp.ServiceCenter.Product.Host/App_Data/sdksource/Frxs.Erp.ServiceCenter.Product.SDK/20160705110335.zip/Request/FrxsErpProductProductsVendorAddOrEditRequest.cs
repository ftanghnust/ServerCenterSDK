/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ProductsVendor.AddOrEdit
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsVendorAddOrEditAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ProductsVendor.AddOrEdit
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsVendorAddOrEditActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ����OR�޸���Ʒ����Ʒ��Ӧ�̹�ϵ��( )
	/// </summary>
	public class FrxsErpProductProductsVendorAddOrEditRequest : RequestBase<Resp.FrxsErpProductProductsVendorAddOrEditResp> 
	{
		/// <summary>
		/// �������ͣ�1Ϊ���Ӳ�Ʒ��Ӧ�̹�ϵ  2Ϊ��������Ӧ����
		/// </summary>
		public int? OptionType { get; set; }
		/// <summary>
		/// ��Ʒ����Ӧ��
		/// </summary>
		public int VendorID { get; set; }
		/// <summary>
		/// �ֿ�ID
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// ����
		/// </summary>
		public IList<ProductsVendorRequestDto> productsVendorList { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.ProductsVendor.AddOrEdit
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.ProductsVendor.AddOrEdit";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.OptionType,
				this.VendorID,
				this.WID,
				this.productsVendorList,
				this.UserId,
				this.UserName }.ToJson();
		}

		/// <summary>
		/// ��Ӧ����Ʒ��ϵ��RequestDto
		/// </summary>
		public class ProductsVendorRequestDto
		{
			/// <summary>
			/// ��ƷID(product.ProductID)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��浥λ
			/// </summary>
			public string Unit { get; set; }
			/// <summary>
			/// ��浥λ�ɹ��۸�
			/// </summary>
			public double BuyPrice { get; set; }
			/// <summary>
			/// �Ƿ�Ϊ����Ӧ��(0:����;1:��)
			/// </summary>
			public int IsMaster { get; set; }
		}

	}
}