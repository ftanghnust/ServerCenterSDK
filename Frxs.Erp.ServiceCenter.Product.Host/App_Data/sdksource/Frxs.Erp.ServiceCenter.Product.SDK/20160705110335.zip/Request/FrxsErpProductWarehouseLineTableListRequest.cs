/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WarehouseLine.TableList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ResponseDto.WarehouseLineTableListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WarehouseLine.TableList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.WarehouseLineTableListRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.WarehouseLine]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductWarehouseLineTableListRequest : RequestBase<Resp.FrxsErpProductWarehouseLineTableListResp> 
	{
		/// <summary>
		/// �ֿ�ID(Warehouse.WID)
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// ������·����
		/// </summary>
		public string LineName { get; set; }
		/// <summary>
		/// �û�����
		/// </summary>
		public string EmpName { get; set; }
		/// <summary>
		/// �����˵绰
		/// </summary>
		public string UserMobile { get; set; }
		/// <summary>
		/// ��������
		/// </summary>
		public string SendW { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WarehouseLine.TableList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WarehouseLine.TableList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.LineName,
				this.EmpName,
				this.UserMobile,
				this.SendW,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}