/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.Get.ByShelfID
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsGetByShelfIDAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:NIck
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.Get.ByShelfID
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsGetByShelfIDAction+WProductsGetV20ActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Model.WProducts]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ���ݻ�λ��Ϣ��ȡ����ǰ��λ����Щ�ֿ���Ʒ
	/// </summary>
	public class FrxsErpProductWProductsGetByShelfIDRequest : RequestBase<Resp.FrxsErpProductWProductsGetByShelfIDResp> 
	{
		/// <summary>
		/// �ֿ�ID
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// ��λID(���ShelfID��ShelfCodeͬʱ��ֵ��,ShelfID����)
		/// </summary>
		public int? ShelfID { get; set; }
		/// <summary>
		/// ��λ���
		/// </summary>
		public string ShelfCode { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WProducts.Get.ByShelfID
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WProducts.Get.ByShelfID";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,this.ShelfID,this.ShelfCode,this.UserId,this.UserName }.ToJson();
		}

	}
}