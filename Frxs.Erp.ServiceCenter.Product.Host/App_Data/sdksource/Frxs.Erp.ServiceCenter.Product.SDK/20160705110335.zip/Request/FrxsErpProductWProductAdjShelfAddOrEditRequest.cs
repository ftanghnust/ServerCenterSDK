/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProductAdjShelf.AddOrEdit
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductAdjShelfAddOrEditAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProductAdjShelf.AddOrEdit
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.WProductAdjShelfAddOrEditActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��λ����¼���༭
	/// </summary>
	public class FrxsErpProductWProductAdjShelfAddOrEditRequest : RequestBase<Resp.FrxsErpProductWProductAdjShelfAddOrEditResp> 
	{
		/// <summary>
		/// ���ӻ��߱༭
		/// </summary>
		public string Flag { get; set; }
		/// <summary>
		/// �ֿ�ID
		/// </summary>
		public int? WareHouseId { get; set; }
		/// <summary>
		/// ��λ����
		/// </summary>
		public WProductAdjShelfRequestDto WProductAdjShelf { get; set; }
		/// <summary>
		/// ��λ������ϸ
		/// </summary>
		public WProductAdjShelfDetailsRequestDto WProductAdjShelfDetails { get; set; }
		/// <summary>
		/// ��λ������ϸ����
		/// </summary>
		public IList<WProductAdjShelfDetailsRequestDto> orderdetailsList { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WProductAdjShelf.AddOrEdit
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WProductAdjShelf.AddOrEdit";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.Flag,
				this.WareHouseId,
				this.WProductAdjShelf,
				this.WProductAdjShelfDetails,
				this.orderdetailsList,
				this.UserId,
				this.UserName }.ToJson();
		}

		/// <summary>
		/// ��λ����RequestDto
		/// </summary>
		public class WProductAdjShelfRequestDto
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public string AdjID { get; set; }
			/// <summary>
			/// �ֿ�ID(WarehouseID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ״̬(0:δ�ύ;1:��ȷ��;2:�ѹ���;)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// Remark
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ��������(0:����[�̶�])
			/// </summary>
			public int AdjType { get; set; }
		}

		/// <summary>
		/// ��λ������ϸRequestDetailsDto����
		/// </summary>
		public class WProductAdjShelfDetailsRequestDto
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public long ID { get; set; }
			/// <summary>
			/// ����ID(WProductAdjPrice.AdjID)
			/// </summary>
			public string AdjID { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID ����)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ���ƷID(WProducts.WProductID)
			/// </summary>
			public int WProductID { get; set; }
			/// <summary>
			/// ��ƷID(product.ProductID)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��浥λ
			/// </summary>
			public string Unit { get; set; }
			/// <summary>
			/// ԭ����ID
			/// </summary>
			public int OldShelfID { get; set; }
			/// <summary>
			/// ԭ���ܱ��
			/// </summary>
			public string OldShelfCode { get; set; }
			/// <summary>
			/// �»���ID
			/// </summary>
			public int ShelfID { get; set; }
			/// <summary>
			/// �»��ܱ��
			/// </summary>
			public string ShelfCode { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
		}

	}
}