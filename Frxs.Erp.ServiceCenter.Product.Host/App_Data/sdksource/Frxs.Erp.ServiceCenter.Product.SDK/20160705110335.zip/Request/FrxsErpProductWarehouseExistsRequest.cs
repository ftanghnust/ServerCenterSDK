/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Warehouse.Exists
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.�ֿ�.WarehouseExistsAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Warehouse.Exists
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.�ֿ�.WarehouseExistsAction+WarehouseExistsActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Boolean
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ���� WID����Wcode �жϲֿ��Ƿ��Ѿ�����
	/// true��ʾ���� false��ʾ������
	/// </summary>
	public class FrxsErpProductWarehouseExistsRequest : RequestBase<Resp.FrxsErpProductWarehouseExistsResp> 
	{
		/// <summary>
		/// �ֿ�ID(��1000��ʼ���)
		/// </summary>
		public int? WID { get; set; }
		/// <summary>
		/// �ֿ���(Ψһ)
		/// </summary>
		public string WCode { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Warehouse.Exists
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Warehouse.Exists";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,this.WCode,this.UserId,this.UserName }.ToJson();
		}

	}
}