/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Shelf.List
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ResponseDto.Shelf.ShelfListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Shelf.List
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ShelfListRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.IList`1[Frxs.Erp.ServiceCenter.Product.Model.Shelf]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductShelfListRequest : RequestBase<Resp.FrxsErpProductShelfListResp> 
	{
		/// <summary>
		/// ��λ���(ͬһ���ֿⲻ���ظ�)
		/// </summary>
		public string ShelfCodeStart { get; set; }
		/// <summary>
		/// ��λ���(ͬһ���ֿⲻ���ظ�)
		/// </summary>
		public string ShelfCodeEnd { get; set; }
		/// <summary>
		/// �ֿ�ID(Warehouse.WID)
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// ��������ID(ShelfArea.ShelfAreaID)
		/// </summary>
		public int? ShelfAreaID { get; set; }
		/// <summary>
		/// ��λ��ż���
		/// </summary>
		public IList<string> ShelfCodeList { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Shelf.List
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Shelf.List";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ShelfCodeStart,
				this.ShelfCodeEnd,
				this.WID,
				this.ShelfAreaID,
				this.ShelfCodeList,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}