/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.MasterVendor.Set
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsMasterVendorSet
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.MasterVendor.Set
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsMasterVendorSet+WProductsMasterVendorSetRequestDto
* RequiredUserIdAndUserName:True
* RequireHttps:False
* ResponseDtoType:System.Nullable`1[System.Int32]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ���òֿ���Ʒ����Ӧ��;�����ɹ��󷵻�����Ӧ��ID
	/// </summary>
	public class FrxsErpProductWProductsMasterVendorSetRequest : RequestBase<Resp.FrxsErpProductWProductsMasterVendorSetResp> 
	{
		/// <summary>
		/// �ֿ���
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// ��Ʒ���
		/// </summary>
		public int ProductId { get; set; }
		/// <summary>
		/// ����Ӧ�̱��
		/// </summary>
		public int VendorID { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WProducts.MasterVendor.Set
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WProducts.MasterVendor.Set";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,this.ProductId,this.VendorID,this.UserId,this.UserName }.ToJson();
		}

	}
}