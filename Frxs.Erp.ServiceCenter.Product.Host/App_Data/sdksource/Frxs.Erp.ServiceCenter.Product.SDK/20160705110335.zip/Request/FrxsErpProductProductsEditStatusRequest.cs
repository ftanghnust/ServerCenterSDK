/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Products.EditStatus
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsEditStatusAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Products.EditStatus
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsEditStatusRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.NullResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// �޸���Ʒ״̬(�ܲ���Ʒ״̬(0:����;1:����[�������Ʒ���ٲɹ�,����������]);2:��̭[��̭����Ʒ���ٲɹ�,����������]))
	/// </summary>
	public class FrxsErpProductProductsEditStatusRequest : RequestBase<ResponseBase> 
	{
		/// <summary>
		/// ��Ʒ����б�
		/// </summary>
		public ICollection<Int32> ProductIds { get; set; }
		/// <summary>
		/// �ı���״̬
		/// </summary>
		public int Status { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Products.EditStatus
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Products.EditStatus";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ProductIds,this.Status,this.UserId,this.UserName }.ToJson();
		}

	}
}