/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.Sale.List.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsSaleListGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.Sale.List.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsSaleListGetAction+WProductsSaleListGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.WProductsSaleQueryModel]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��ȡ�ֿ����ͼ۸��б�
	/// </summary>
	public class FrxsErpProductWProductsSaleListGetRequest : RequestBase<Resp.FrxsErpProductWProductsSaleListGetResp> 
	{
		/// <summary>
		/// ��Ӧ�Ĳֿ�ID��ţ��˲������봫��
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// SKU��Ϣ
		/// </summary>
		public string SKU { get; set; }
		/// <summary>
		/// �Ƿ����Σ�SKU��������ģ������
		/// </summary>
		public bool? SKULikeSearch { get; set; }
		/// <summary>
		/// ��Ʒ�ؼ���
		/// </summary>
		public string ProductName { get; set; }
		/// <summary>
		/// ��������
		/// </summary>
		public string BarCode { get; set; }
		/// <summary>
		/// ��ƷID�������ǲ���ID�����Ǳ����Կ�ͷ(����ȫ��������)
		/// </summary>
		public string ProductId { get; set; }
		/// <summary>
		/// �Ƿ���˱�ע; true ���ˣ�false������
		/// </summary>
		public bool? SaleBackFlag { get; set; }
		/// <summary>
		/// �Ƿ��ѯ����״̬-Ĭ�ϲ�ѯ����״̬ Ҳ���� WState=1
		/// </summary>
		public bool? AllWState { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public IList<int> ProductIds { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WProducts.Sale.List.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WProducts.Sale.List.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.SKU,
				this.SKULikeSearch,
				this.ProductName,
				this.BarCode,
				this.ProductId,
				this.SaleBackFlag,
				this.AllWState,
				this.ProductIds,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}