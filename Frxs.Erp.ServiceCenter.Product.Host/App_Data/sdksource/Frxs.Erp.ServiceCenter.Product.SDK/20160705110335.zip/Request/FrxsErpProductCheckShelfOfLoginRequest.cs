/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.CheckShelfOfLogin
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.CheckShelfOfLoginAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.CheckShelfOfLogin
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.CheckShelfOfLoginAction+CheckShelfOfLoginActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Boolean
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// �жϵ�¼�û��Ļ�λ�Ƿ����
	/// </summary>
	public class FrxsErpProductCheckShelfOfLoginRequest : RequestBase<Resp.FrxsErpProductCheckShelfOfLoginResp> 
	{
		/// <summary>
		/// ��¼��
		/// </summary>
		public string UserAccount { get; set; }
		/// <summary>
		/// ����
		/// </summary>
		public string UserPwd { get; set; }
		/// <summary>
		/// ��λ���
		/// </summary>
		public string ShelfCode { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.CheckShelfOfLogin
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.CheckShelfOfLogin";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.UserAccount,this.UserPwd,this.ShelfCode,this.UserId,this.UserName }.ToJson();
		}

	}
}