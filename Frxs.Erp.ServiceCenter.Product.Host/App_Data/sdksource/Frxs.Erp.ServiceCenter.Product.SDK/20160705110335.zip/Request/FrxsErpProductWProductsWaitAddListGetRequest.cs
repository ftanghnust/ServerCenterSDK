/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.WaitAdd.List.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsWaitAddListGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.WaitAdd.List.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsWaitAddListGetAction+WProductsWaitAddListGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.WProductsWaitAddListModel]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��δ���뵽�ֿ��̨����Ʒ�б�
	/// </summary>
	public class FrxsErpProductWProductsWaitAddListGetRequest : RequestBase<Resp.FrxsErpProductWProductsWaitAddListGetResp> 
	{
		/// <summary>
		/// �ֿ��ţ����봫
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// ��Ʒ���ƹؼ���
		/// </summary>
		public string ProductName { get; set; }
		/// <summary>
		/// ��Ʒ����
		/// </summary>
		public string BarCode { get; set; }
		/// <summary>
		/// erp����
		/// </summary>
		public string SKU { get; set; }
		/// <summary>
		/// ��������1��
		/// </summary>
		public int? CategoryId1 { get; set; }
		/// <summary>
		/// ��������2��
		/// </summary>
		public int? CategoryId2 { get; set; }
		/// <summary>
		/// ��������3��
		/// </summary>
		public int? CategoryId3 { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WProducts.WaitAdd.List.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WProducts.WaitAdd.List.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.ProductName,
				this.BarCode,
				this.SKU,
				this.CategoryId1,
				this.CategoryId2,
				this.CategoryId3,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}