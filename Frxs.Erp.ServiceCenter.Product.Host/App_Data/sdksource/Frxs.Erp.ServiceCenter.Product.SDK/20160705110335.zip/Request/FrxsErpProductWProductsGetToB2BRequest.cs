/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.Get.ToB2B
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsGetToB2BAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.Get.ToB2B
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsGetToB2BAction+WProductsGetToB2BActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsGetToB2BAction+WProductsGetToB2BActionResponsetDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��ȡ������Ʒ��Ϣ(�ų��޹���) ������ҳ�Ͳ���ҳ����
	/// </summary>
	public class FrxsErpProductWProductsGetToB2BRequest : RequestBase<Resp.FrxsErpProductWProductsGetToB2BResp> 
	{
		/// <summary>
		/// �Ƿ��ҳ(0��ʾ���֣�1��ʾ��ҳ)
		/// </summary>
		public int? IsPage { get; set; }
		/// <summary>
		/// PageIndex
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// PageSize
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// �����ֶ�
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// �ֿ��ţ�������д
		/// </summary>
		public int? WID { get; set; }
		/// <summary>
		/// ��ƷID
		/// </summary>
		public IList<int> ProductIds { get; set; }
		/// <summary>
		/// ��ƷSKU
		/// </summary>
		public IList<string> SKUs { get; set; }
		/// <summary>
		/// �ŵ�ID
		/// </summary>
		public int? ShopID { get; set; }
		/// <summary>
		/// ��ƷSKU
		/// </summary>
		public string SKU { get; set; }
		/// <summary>
		/// ��Ʒ����
		/// </summary>
		public string ProductName { get; set; }
		/// <summary>
		/// ��Ӫ����1
		/// </summary>
		public string CategoryId1 { get; set; }
		/// <summary>
		/// ��Ӫ����2
		/// </summary>
		public string CategoryId2 { get; set; }
		/// <summary>
		/// ��Ӫ����3
		/// </summary>
		public string CategoryId3 { get; set; }
		/// <summary>
		/// �ؼ���
		/// </summary>
		public string KeyWord { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WProducts.Get.ToB2B
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WProducts.Get.ToB2B";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.IsPage,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.WID,
				this.ProductIds,
				this.SKUs,
				this.ShopID,
				this.SKU,
				this.ProductName,
				this.CategoryId1,
				this.CategoryId2,
				this.CategoryId3,
				this.KeyWord,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}