/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.AttributesValues.Delete
* ActionType:Frxs.ServiceCenter.Product.Api.Actions.AttributesValuesDeleteAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.AttributesValues.Delete
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.ServiceCenter.Product.Api.Actions.AttributesValuesDeleteAction+AttributesValuesDeleteRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.NullResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductAttributesValuesDeleteRequest : RequestBase<ResponseBase> 
	{
		/// <summary>
		/// ����ID
		/// </summary>
		public int ValuesId { get; set; }
		/// <summary>
		/// ���Ա�ID(Attribute.AttributeID)
		/// </summary>
		public int AttributeId { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.AttributesValues.Delete
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.AttributesValues.Delete";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ValuesId,this.AttributeId,this.UserId,this.UserName }.ToJson();
		}

	}
}