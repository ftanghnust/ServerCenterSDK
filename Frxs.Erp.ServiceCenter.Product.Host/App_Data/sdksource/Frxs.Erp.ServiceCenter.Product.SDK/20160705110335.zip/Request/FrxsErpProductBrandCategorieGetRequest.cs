/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.BrandCategorie.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.BrandCategorieListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.BrandCategorie.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.BrandCategorieListAction+BrandCategorieListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.BrandCategories]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// Ʒ�Ʒ����б�
	/// </summary>
	public class FrxsErpProductBrandCategorieGetRequest : RequestBase<Resp.FrxsErpProductBrandCategorieGetResp> 
	{
		/// <summary>
		/// Ʒ��ID���ϣ�
		/// 1.����˲�������Ϊnull�����ѯ�����е�Ʒ�Ʒ��༯��
		/// 2.���ָ���˲�������ôֵ��ѯ��ָ����Ʒ�Ʒ��༯��
		/// </summary>
		public List<int> BrandIds { get; set; }
		/// <summary>
		/// Ʒ������(��������ؼ���)
		/// </summary>
		public string BrandName { get; set; }
		/// <summary>
		/// �Ƿ���LOGO���ɿգ���ָ����ѯ�����еģ�
		/// </summary>
		public bool? HasLogo { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.BrandCategorie.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.BrandCategorie.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.BrandIds,
				this.BrandName,
				this.HasLogo,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}