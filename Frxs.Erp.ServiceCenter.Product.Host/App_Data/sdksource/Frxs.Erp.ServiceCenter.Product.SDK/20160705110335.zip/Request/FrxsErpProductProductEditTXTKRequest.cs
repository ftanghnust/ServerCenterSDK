/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Product.EditTXTK
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductEditTXTKAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Product.EditTXTK
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsEditTxtkRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.NullResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��Ʒ�޸�����ͼ����
	/// </summary>
	public class FrxsErpProductProductEditTXTKRequest : RequestBase<ResponseBase> 
	{
		/// <summary>
		/// ��Ʒ���
		/// </summary>
		public int ProductId { get; set; }
		/// <summary>
		/// ����ͼ����
		/// </summary>
		public string Txtkid { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Product.EditTXTK
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Product.EditTXTK";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ProductId,this.Txtkid,this.UserId,this.UserName }.ToJson();
		}

	}
}