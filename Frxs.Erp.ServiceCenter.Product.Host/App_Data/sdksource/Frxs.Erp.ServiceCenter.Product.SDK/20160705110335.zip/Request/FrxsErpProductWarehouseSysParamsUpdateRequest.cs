/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Warehouse.SysParams.Update
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WarehouseSysParamsUpdateAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Warehouse.SysParams.Update
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WarehouseSysParamsUpdateAction+WarehouseSysParamsUpdateActionRequestDto
* RequiredUserIdAndUserName:True
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.NullResponseDto
* Route:
* UnloadCacheKeys:System.String[]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ���²ֿ�ҵ��������ã�ǰ�˵���ֱ�Ӹ��ݷ��ص�flag=0���ж��Ƿ�ɹ�
	/// </summary>
	public class FrxsErpProductWarehouseSysParamsUpdateRequest : RequestBase<ResponseBase> 
	{
		/// <summary>
		/// �ֿ��ţ����봫��
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// �������룬���봫��
		/// </summary>
		public string ParamCode { get; set; }
		/// <summary>
		/// ����ҵ������ֵ�����봫��
		/// </summary>
		public string ParamValue { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Warehouse.SysParams.Update
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Warehouse.SysParams.Update";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,this.ParamCode,this.ParamValue,this.UserId,this.UserName }.ToJson();
		}

	}
}