/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ReportGet
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.����.ReportGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ReportGet
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ReportGetRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.String
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// �����ӿ�
	/// </summary>
	public class FrxsErpProductReportGetRequest : RequestBase<Resp.FrxsErpProductReportGetResp> 
	{
		/// <summary>
		/// �ֿ���
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// �洢��������
		/// </summary>
		public string Procedure_Name { get; set; }
		/// <summary>
		/// ����������s1��s2...sn����
		/// </summary>
		public IList<parameter> parameters { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.ReportGet
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.ReportGet";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,this.Procedure_Name,this.parameters,this.UserId,this.UserName }.ToJson();
		}

		/// <summary>
		/// 
		/// </summary>
		public class parameter
		{
			/// <summary>
			/// 
			/// </summary>
			public string key { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string value { get; set; }
		}

	}
}