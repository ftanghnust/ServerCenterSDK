/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WarehouseEmpShelf.TableList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ResponseDto.WarehouseEmpShelfTableListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WarehouseEmpShelf.TableList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.WarehouseEmpShelfTableListRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.WarehouseEmp]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductWarehouseEmpShelfTableListRequest : RequestBase<Resp.FrxsErpProductWarehouseEmpShelfTableListResp> 
	{
		/// <summary>
		/// �ֿ�ID(Warehouse.WID)
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// �û�����
		/// </summary>
		public string EmpName { get; set; }
		/// <summary>
		/// �û���¼�ʻ�(�ֻ�����;Ա�����;Ψһ[������ɾ����])
		/// </summary>
		public string UserAccount { get; set; }
		/// <summary>
		/// ��������ID(ShelfArea.ShelfAreaID)
		/// </summary>
		public string ShelfAreaID { get; set; }
		/// <summary>
		/// �Ƿ񶳽�(0:δ����;1:�Ѷ���)
		/// </summary>
		public string IsFrozen { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.WarehouseEmpShelf.TableList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.WarehouseEmpShelf.TableList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.EmpName,
				this.UserAccount,
				this.ShelfAreaID,
				this.IsFrozen,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}