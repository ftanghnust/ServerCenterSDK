/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.PickingUpdatePwd
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.PickingUpdatePwdAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.PickingUpdatePwd
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.PickingUpdatePwdAction+PickingUpdatePwdActionRequestDto
* RequiredUserIdAndUserName:True
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.NullResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ����ӿ�-�޸�����
	/// </summary>
	public class FrxsErpProductPickingUpdatePwdRequest : RequestBase<ResponseBase> 
	{
		/// <summary>
		/// ��¼��
		/// </summary>
		public string UserAccount { get; set; }
		/// <summary>
		/// ������
		/// </summary>
		public string OldUserPwd { get; set; }
		/// <summary>
		/// ������
		/// </summary>
		public string NewUserPwd { get; set; }
		/// <summary>
		/// �û�����
		/// </summary>
		public string UserType { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.PickingUpdatePwd
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.PickingUpdatePwd";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.UserAccount,
				this.OldUserPwd,
				this.NewUserPwd,
				this.UserType,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}