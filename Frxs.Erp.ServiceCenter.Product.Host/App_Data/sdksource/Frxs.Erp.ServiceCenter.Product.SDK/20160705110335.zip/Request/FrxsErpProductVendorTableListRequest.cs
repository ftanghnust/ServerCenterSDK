/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Vendor.TableList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.Vendor.VendorTableListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Vendor.TableList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.Vendor.VendorTableListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.Vendor]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��ȡ��Ӧ���б�
	/// </summary>
	public class FrxsErpProductVendorTableListRequest : RequestBase<Resp.FrxsErpProductVendorTableListResp> 
	{
		/// <summary>
		/// ��Ӧ�̱��
		/// </summary>
		public string VendorCode { get; set; }
		/// <summary>
		/// ��Ӧ������
		/// </summary>
		public string VendorName { get; set; }
		/// <summary>
		/// ��Ӧ�̼��
		/// </summary>
		public string VendorShortName { get; set; }
		/// <summary>
		/// ��Ӧ������(VendorType.VendorTypeID)
		/// </summary>
		public string VendorTypeID { get; set; }
		/// <summary>
		/// ��ϵ������
		/// </summary>
		public string LinkMan { get; set; }
		/// <summary>
		/// ״̬(1:����;0:����)
		/// </summary>
		public int? Status { get; set; }
		/// <summary>
		/// ��������
		/// </summary>
		public string Region { get; set; }
		/// <summary>
		/// ���㷽ʽ( �����ֵ�: VendorSettleTimeType)
		/// </summary>
		public string SettleTimeType { get; set; }
		/// <summary>
		/// ��Ӧ�̼���(�����ֵ�: VendorLevel; A:A��;B:B��;C:C��)
		/// </summary>
		public string CreditLevel { get; set; }
		/// <summary>
		/// �ֿ���(ָ���˲ֿ��ŵģ�ֻ��ѯ��Ӧ�Ĳֿ⹩Ӧ��)
		/// </summary>
		public int? WID { get; set; }
		/// <summary>
		/// ����
		/// </summary>
		public string PaymentDateType { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.Vendor.TableList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.Vendor.TableList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.VendorCode,
				this.VendorName,
				this.VendorShortName,
				this.VendorTypeID,
				this.LinkMan,
				this.Status,
				this.Region,
				this.SettleTimeType,
				this.CreditLevel,
				this.WID,
				this.PaymentDateType,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}