/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ShopCategories.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ShopCategoriesGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ShopCategories.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.ShopCategoriesGetAction+ShopCategoriesListRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Model.ShopCategories]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��Ӫ�����б�
	/// </summary>
	public class FrxsErpProductShopCategoriesGetRequest : RequestBase<Resp.FrxsErpProductShopCategoriesGetResp> 
	{
		/// <summary>
		/// ��ȡָ�����༯��ID���������ֵΪnull���򷵻����м���
		/// </summary>
		public List<int> CategoryIds { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.ShopCategories.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.ShopCategories.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.CategoryIds,this.UserId,this.UserName }.ToJson();
		}

	}
}