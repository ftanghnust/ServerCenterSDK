/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.AttributesProducts.GetList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.AttributesProductsGetListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.AttributesProducts.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.AttributesProductsGetListAction+AttributesProductsGetListRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.AttributesProductsGetListAction+AttributesProductsGetListResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// ��ȡ������Ʒ
	/// </summary>
	public class FrxsErpProductAttributesProductsGetListRequest : RequestBase<Resp.FrxsErpProductAttributesProductsGetListResp> 
	{
		/// <summary>
		/// ����ID
		/// </summary>
		public int AttributeId { get; set; }
		/// <summary>
		/// SKU����
		/// </summary>
		public string SKU { get; set; }
		/// <summary>
		/// ���ֵ
		/// </summary>
		public string ValueStr { get; set; }
		/// <summary>
		/// ��ǰҳ(Ĭ��1)
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// ��ҳ��С��Ĭ��10��
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.AttributesProducts.GetList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.AttributesProducts.GetList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.AttributeId,
				this.SKU,
				this.ValueStr,
				this.PageIndex,
				this.PageSize,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}