/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ShelfArea.Save
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ShelfArea.ShelfAreaSaveAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ShelfArea.Save
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ShelfAreaSaveRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductShelfAreaSaveRequest : RequestBase<Resp.FrxsErpProductShelfAreaSaveResp> 
	{
		/// <summary>
		/// ID(����)
		/// </summary>
		public int ShelfAreaID { get; set; }
		/// <summary>
		/// �ֿ�ID(Warehouse.WID)
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// �ֿ�������(�����ֵ䣺ShelfAreaCode)
		/// </summary>
		public string ShelfAreaCode { get; set; }
		/// <summary>
		/// ��������
		/// </summary>
		public string ShelfAreaName { get; set; }
		/// <summary>
		/// ���APP�����ʾ��
		/// </summary>
		public int PickingMaxRecord { get; set; }
		/// <summary>
		/// ����
		/// </summary>
		public int SerialNumber { get; set; }
		/// <summary>
		/// ��ע
		/// </summary>
		public string Remark { get; set; }
		/// <summary>
		/// �����û�ID
		/// </summary>
		public int CreateUserID { get; set; }
		/// <summary>
		/// �����û�����
		/// </summary>
		public string CreateUserName { get; set; }
		/// <summary>
		/// ����޸�ɾ���û�ID
		/// </summary>
		public int ModifyUserID { get; set; }
		/// <summary>
		/// ����޸�ɾ���û�����
		/// </summary>
		public string ModifyUserName { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Product.ShelfArea.Save
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Product.ShelfArea.Save";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ShelfAreaID,
				this.WID,
				this.ShelfAreaCode,
				this.ShelfAreaName,
				this.PickingMaxRecord,
				this.SerialNumber,
				this.Remark,
				this.CreateUserID,
				this.CreateUserName,
				this.ModifyUserID,
				this.ModifyUserName,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}