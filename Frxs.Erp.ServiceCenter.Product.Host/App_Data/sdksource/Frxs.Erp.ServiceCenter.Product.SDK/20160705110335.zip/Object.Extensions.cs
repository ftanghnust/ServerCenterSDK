/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 11/3/2015 1:31:29 PM
 * *******************************************************/
using Newtonsoft.Json;

namespace Frxs.Erp.ServiceCenter.Product.SDK
{
    /// <summary>
    /// 
    /// </summary>
    internal static class ObjectExtensions
    {
        /// <summary>
        /// ���л���JSON
        /// </summary>
        /// <param name="obj">�����������</param>
        /// <returns></returns>
        public static string ToJson(this object obj)
        {
            return JsonConvert.SerializeObject(obj);
        }
    }
}
