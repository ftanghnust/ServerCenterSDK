/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.BaseProductList.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.BaseProductListGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.BaseProductList.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.BaseProductListGetRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Actions.BaseProductListGetAction+BaseProductListGetResponseDto]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ĸ��Ʒ�б���ѯ����
	/// </summary>
	public class FrxsErpProductBaseProductListGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductBaseProductListGetRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductBaseProductListGetRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<BaseProductListGetResponseDto> ItemList { get; set; }
		}

		/// <summary>
		/// ĸ��Ʒ�б���ѯ �������ݶ���
		/// </summary>
		public class BaseProductListGetResponseDto
		{
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ĸ��Ʒ����
			/// </summary>
			public int BaseProdutId { get; set; }
			/// <summary>
			/// �Ƿ������Ʒ
			/// </summary>
			public int IsMutiAttribute { get; set; }
			/// <summary>
			/// �Ƿ���ĸ��Ʒ
			/// </summary>
			public int IsBaseProductId { get; set; }
			/// <summary>
			/// ��ƷSKU
			/// </summary>
			public string Sku { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// ĸ��Ʒ����
			/// </summary>
			public string ProductBaseName { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public IList<ProductsAttributes> AttributeNames { get; set; }
			/// <summary>
			/// �������������б�
			/// </summary>
			public string AttributeNamesString { get; set; }
			/// <summary>
			/// ��Ʒ���뼯��
			/// </summary>
			public IList<string> Barcodes { get; set; }
			/// <summary>
			/// ��Ʒ���뼯���ַ���
			/// </summary>
			public string BarcodesString { get; set; }
			/// <summary>
			/// �Ƿ��������Ʒ
			/// </summary>
			public int IsVendor { get; set; }
			/// <summary>
			/// ��Ӫ����1
			/// </summary>
			public int ShopCategoryId1 { get; set; }
			/// <summary>
			/// ��Ӫ����2
			/// </summary>
			public int ShopCategoryId2 { get; set; }
			/// <summary>
			/// ��Ӫ����3
			/// </summary>
			public int ShopCategoryId3 { get; set; }
			/// <summary>
			/// ��Ӫ��������
			/// </summary>
			public string ShopCategoryName { get; set; }
			/// <summary>
			/// Ʒ��1
			/// </summary>
			public int BrandId1 { get; set; }
			/// <summary>
			/// Ʒ��2
			/// </summary>
			public int BrandId2 { get; set; }
			/// <summary>
			/// ��Ʒ����1
			/// </summary>
			public int CategoryId1 { get; set; }
			/// <summary>
			/// ��Ʒ����2
			/// </summary>
			public int CategoryId2 { get; set; }
			/// <summary>
			/// ��Ʒ����3
			/// </summary>
			public int CategoryId3 { get; set; }
			/// <summary>
			/// ��Ʒ��������
			/// </summary>
			public string CategoryName { get; set; }
			/// <summary>
			/// ��ƷͼƬ���������ID
			/// </summary>
			public int ImageProductId { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string TXTKID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string MutAttributes { get; set; }
		}

		/// <summary>
		/// ��Ʒ��������ֵ��ProductsAttributesʵ����
		/// </summary>
		public class ProductsAttributes
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int ID { get; set; }
			/// <summary>
			/// ��ƷID(Product.ProductId)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ���Ա�ID(Attribute.AttributeId��
			/// </summary>
			public int AttributeId { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string AttributeName { get; set; }
			/// <summary>
			/// ����ֵ��ID(AttributeValues.ValueId��
			/// </summary>
			public int ValuesId { get; set; }
			/// <summary>
			/// ֵ
			/// </summary>
			public string ValueStr { get; set; }
			/// <summary>
			/// �����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
		}

	}
}