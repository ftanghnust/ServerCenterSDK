/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Warehouse.SysParams.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WarehouseSysParamsGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Warehouse.SysParams.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WarehouseSysParamsGetAction+WarehouseSysParamsGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Model.SysParams]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// (���Ͻӿ�)��ȡ��Ӧ�ֿ�ϵͳ�����б���Ϣ��ע��˽ӿ��и�ҵ���߼�����������ֿ�δ���ö�Ӧ�Ĳ�����ȡ���Ľ�����ϵͳȫ�����õ�
	/// </summary>
	public class FrxsErpProductWarehouseSysParamsGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public List<FrxsErpProductWarehouseSysParamsGetRespData> Data { get; set; }

		/// <summary>
		/// SysParamsʵ����
		/// </summary>
		public class FrxsErpProductWarehouseSysParamsGetRespData
		{
			/// <summary>
			/// ���
			/// </summary>
			public string ParamCode { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string ParamName { get; set; }
			/// <summary>
			/// ����ֵ(ȫϵͳԤ��ֵ)
			/// </summary>
			public string ParamValue { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
		}

	}
}