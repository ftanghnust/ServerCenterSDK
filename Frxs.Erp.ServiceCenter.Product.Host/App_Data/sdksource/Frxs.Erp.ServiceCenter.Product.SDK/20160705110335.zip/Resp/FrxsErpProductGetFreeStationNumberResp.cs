/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.GetFreeStationNumber
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.PickingGetFreeStationNumberAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.GetFreeStationNumber
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.PickingGetFreeStationNumberAction+PickingGetFreeStationNumberActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.PickingGetFreeStationNumberAction+PickingGetFreeStationNumberActionResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ����ӿ�-��ȡ���д�װ��
	/// </summary>
	public class FrxsErpProductGetFreeStationNumberResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductGetFreeStationNumberRespData Data { get; set; }

		/// <summary>
		/// ���ýӿ����
		/// </summary>
		public class FrxsErpProductGetFreeStationNumberRespData
		{
			/// <summary>
			/// ���(����)
			/// </summary>
			public int ID { get; set; }
			/// <summary>
			/// �ֿ���
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ��װ������
			/// </summary>
			public int StationNumber { get; set; }
		}

	}
}