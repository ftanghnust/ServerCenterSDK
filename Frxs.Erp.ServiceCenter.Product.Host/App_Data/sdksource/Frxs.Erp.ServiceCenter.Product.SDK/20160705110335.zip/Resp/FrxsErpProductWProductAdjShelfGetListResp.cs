/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProductAdjShelf.GetList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductAdjShelfGetListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProductAdjShelf.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.WProductAdjShelfGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.WProductAdjShelf]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��λ���� ��ҳ��ѯ
	/// </summary>
	public class FrxsErpProductWProductAdjShelfGetListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductWProductAdjShelfGetListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductWProductAdjShelfGetListRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<WProductAdjShelf> ItemList { get; set; }
		}

		/// <summary>
		/// �ֿ���Ʒ���ܵ�����WProductAdjShelfʵ����
		/// </summary>
		public class WProductAdjShelf
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public string AdjID { get; set; }
			/// <summary>
			/// �ֿ�ID(WarehouseID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ״̬(0:δ�ύ;1:��ȷ��;2:�ѹ���;)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// ȷ��ʱ��
			/// </summary>
			public DateTime? ConfTime { get; set; }
			/// <summary>
			/// ȷ���û�ID
			/// </summary>
			public int? ConfUserID { get; set; }
			/// <summary>
			/// ȷ���û�����
			/// </summary>
			public string ConfUserName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime? PostingTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int? PostingUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string PostingUserName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// ��������(0:����[�̶�])
			/// </summary>
			public int AdjType { get; set; }
			/// <summary>
			/// Remark
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// �ܻ�λ������
			/// </summary>
			public int TotalShelfCount { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string StatusToStr { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public IList<WProductAdjShelfDetails> wProductAdjShelfDetailsList { get; set; }
		}

		/// <summary>
		/// �ֿ���Ʒ���ܵ�����ϸ��WProductAdjShelfDetailsʵ����
		/// </summary>
		public class WProductAdjShelfDetails
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public long ID { get; set; }
			/// <summary>
			/// ����ID(WProductAdjPrice.AdjID)
			/// </summary>
			public string AdjID { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID ����)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ���ƷID(WProducts.WProductID)
			/// </summary>
			public int WProductID { get; set; }
			/// <summary>
			/// ��ƷID(product.ProductID)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��浥λ
			/// </summary>
			public string Unit { get; set; }
			/// <summary>
			/// ԭ����ID
			/// </summary>
			public int OldShelfID { get; set; }
			/// <summary>
			/// ԭ���ܱ��
			/// </summary>
			public string OldShelfCode { get; set; }
			/// <summary>
			/// �»���ID
			/// </summary>
			public int ShelfID { get; set; }
			/// <summary>
			/// �»��ܱ��
			/// </summary>
			public string ShelfCode { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ��װ��
			/// </summary>
			public decimal BigPackingQty { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string SKU { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string BarCode { get; set; }
		}

	}
}