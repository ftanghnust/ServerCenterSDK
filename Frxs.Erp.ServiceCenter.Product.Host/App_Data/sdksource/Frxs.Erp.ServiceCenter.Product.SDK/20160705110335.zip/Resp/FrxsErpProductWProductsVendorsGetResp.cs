/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.Vendors.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsVendorsGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.Vendors.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsVendorsGetAction+WProductsVendorsGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Model.ProductVendorModel]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ�ֿ���Ʒ��Ӧ���б�
	/// </summary>
	public class FrxsErpProductWProductsVendorsGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public List<FrxsErpProductWProductsVendorsGetRespData> Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductWProductsVendorsGetRespData
		{
			/// <summary>
			/// �ֿ⹩Ӧ��ID
			/// </summary>
			public long ID { get; set; }
			/// <summary>
			/// ��Ӧ��ID
			/// </summary>
			public int VendorID { get; set; }
			/// <summary>
			/// ��Ӧ�̱���
			/// </summary>
			public string VendorCode { get; set; }
			/// <summary>
			/// ��Ӧ������
			/// </summary>
			public string VendorName { get; set; }
			/// <summary>
			/// ��Ӧ����ϵ��
			/// </summary>
			public string LinkMan { get; set; }
			/// <summary>
			/// ��Ӧ����ϵ�绰
			/// </summary>
			public string Telephone { get; set; }
			/// <summary>
			/// ��Ӧ��״̬; ״̬(1:����;0:����)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// ��Ӧ����������
			/// </summary>
			public string VendorTypeName { get; set; }
			/// <summary>
			/// �Ƿ�����Ӧ��;1�ǣ�0����
			/// </summary>
			public int IsMaster { get; set; }
		}

	}
}