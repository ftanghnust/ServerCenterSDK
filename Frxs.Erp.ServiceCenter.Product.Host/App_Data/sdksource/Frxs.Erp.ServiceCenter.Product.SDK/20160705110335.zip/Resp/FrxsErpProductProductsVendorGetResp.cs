/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ProductsVendor.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsVendorGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ProductsVendor.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsVendorGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.ProductsVendor]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ��Ӧ����Ʒ��ϵ��������ҳ�Ͳ���ҳ���֣�
	/// </summary>
	public class FrxsErpProductProductsVendorGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductProductsVendorGetRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductProductsVendorGetRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<ProductsVendor> ItemList { get; set; }
		}

		/// <summary>
		/// ��Ӧ����Ʒ��ProductsVendorʵ����
		/// </summary>
		public class ProductsVendor
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public long ID { get; set; }
			/// <summary>
			/// �ֿ�ID
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ��ƷID(product.ProductID)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��Ʒ����Ӧ��
			/// </summary>
			public int VendorID { get; set; }
			/// <summary>
			/// ��浥λ
			/// </summary>
			public string Unit { get; set; }
			/// <summary>
			/// ��浥λ�ɹ��۸�
			/// </summary>
			public double BuyPrice { get; set; }
			/// <summary>
			/// �Ƿ�Ϊ����Ӧ��(0:����;1:��)
			/// </summary>
			public int IsMaster { get; set; }
			/// <summary>
			/// ��浥λ���½���
			/// </summary>
			public double LastBuyPrice { get; set; }
			/// <summary>
			/// ���²ɹ����ʱ��
			/// </summary>
			public DateTime LastBuyTime { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// �����޸�ɾ��ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸�ɾ���û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸�ɾ���û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string SKU { get; set; }
			/// <summary>
			/// ��������1
			/// </summary>
			public string CategoryName1 { get; set; }
			/// <summary>
			/// ��������2
			/// </summary>
			public string CategoryName2 { get; set; }
			/// <summary>
			/// ��������3
			/// </summary>
			public string CategoryName3 { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string BarCode { get; set; }
			/// <summary>
			/// ��װ��
			/// </summary>
			public string BigPackingQty { get; set; }
		}

	}
}