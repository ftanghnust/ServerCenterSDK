/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ProductsDescription.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsDescriptionAndPictureGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ProductsDescription.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsDescriptionAndPictureGetRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsDescriptionAndPictureGetAction+ProductsDescriptionAndPictureGetResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ��Ʒ������Ϣ
	/// </summary>
	public class FrxsErpProductProductsDescriptionGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductProductsDescriptionGetRespData Data { get; set; }

		/// <summary>
		/// �����Ʒͼ������
		/// </summary>
		public class FrxsErpProductProductsDescriptionGetRespData
		{
			/// <summary>
			/// ��Ʒ���
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ĸ��Ʒ���
			/// </summary>
			public int BaseProductId { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string Description { get; set; }
			/// <summary>
			/// ĸ��Ʒͼ��
			/// </summary>
			public ICollection<ProductsDescriptionPicture> ProductsDescriptionPicture { get; set; }
		}

		/// <summary>
		/// ������Ʒͼ�ı�ProductsDescriptionPictureʵ����
		/// </summary>
		public class ProductsDescriptionPicture
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int ID { get; set; }
			/// <summary>
			/// ��Ʒĸ��ID
			/// </summary>
			public int BaseProductId { get; set; }
			/// <summary>
			/// ԭͼ·��
			/// </summary>
			public string ImageUrlOrg { get; set; }
			/// <summary>
			/// zipΪ400*400��ͼ·��
			/// </summary>
			public string ImageUrl400x400 { get; set; }
			/// <summary>
			/// zipΪ200*200��ͼ·��
			/// </summary>
			public string ImageUrl200x200 { get; set; }
			/// <summary>
			/// zipΪ120*120��ͼ·��
			/// </summary>
			public string ImageUrl120x120 { get; set; }
			/// <summary>
			/// zipΪ60*60��ͼ·��
			/// </summary>
			public string ImageUrl60x60 { get; set; }
			/// <summary>
			/// ����(1,2,3..)
			/// </summary>
			public int OrderNumber { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
		}

	}
}