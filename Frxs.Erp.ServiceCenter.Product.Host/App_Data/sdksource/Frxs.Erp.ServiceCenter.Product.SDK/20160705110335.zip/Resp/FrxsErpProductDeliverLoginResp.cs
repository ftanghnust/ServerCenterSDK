/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.DeliverLogin
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.DeliverLoginAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.DeliverLogin
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.DeliverLoginAction+DeliverLoginActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.DeliverLoginAction+DeliverLoginActionResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ���ͽӿ�-��¼
	/// </summary>
	public class FrxsErpProductDeliverLoginResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductDeliverLoginRespData Data { get; set; }

		/// <summary>
		/// �ӿڵ��÷��ز���
		/// </summary>
		public class FrxsErpProductDeliverLoginRespData
		{
			/// <summary>
			/// Ա�����
			/// </summary>
			public int EmpID { get; set; }
			/// <summary>
			/// �û�����
			/// </summary>
			public string EmpName { get; set; }
			/// <summary>
			/// ���ֱ��
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �û������ֻ�����
			/// </summary>
			public string UserMobile { get; set; }
			/// <summary>
			/// �Ƿ����鳤
			/// </summary>
			public int IsMaster { get; set; }
			/// <summary>
			/// �Ƿ񶳽�
			/// </summary>
			public int IsFrozen { get; set; }
			/// <summary>
			/// �Ƿ�����
			/// </summary>
			public int IsLocked { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��
			/// </summary>
			public int IsDeleted { get; set; }
			/// <summary>
			/// ������·����
			/// </summary>
			public string LineIDs { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��
			/// </summary>
			public string PasswordSalt { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��
			/// </summary>
			public string UserGuid { get; set; }
			/// <summary>
			/// �û��˺�
			/// </summary>
			public string UserAccount { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string UserPwd { get; set; }
			/// <summary>
			/// �����ֿ�ID
			/// </summary>
			public int WareHouseWID { get; set; }
		}

	}
}