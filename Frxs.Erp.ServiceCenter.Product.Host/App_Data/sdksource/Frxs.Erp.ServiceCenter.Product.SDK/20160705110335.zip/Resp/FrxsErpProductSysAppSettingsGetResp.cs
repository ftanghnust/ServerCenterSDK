/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.SysAppSettings.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.SysAppSettings.SysAppSettingsGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.SysAppSettings.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.SysAppSettings.SysAppSettingsGetAction+SysAppSettingsGetRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Model.SysAppSettings
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductSysAppSettingsGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductSysAppSettingsGetRespData Data { get; set; }

		/// <summary>
		/// ϵͳ�ַ������ñ�SysAppSettingsʵ����
		/// </summary>
		public class FrxsErpProductSysAppSettingsGetRespData
		{
			/// <summary>
			/// ID����
			/// </summary>
			public int ID { get; set; }
			/// <summary>
			/// �ֿ�ID
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ����Ψһ��ʶ
			/// </summary>
			public string SKey { get; set; }
			/// <summary>
			/// ������Ϣ1
			/// </summary>
			public string SVal1 { get; set; }
			/// <summary>
			/// ������Ϣ2
			/// </summary>
			public string SVal2 { get; set; }
			/// <summary>
			/// ������Ϣ3
			/// </summary>
			public string SVal3 { get; set; }
			/// <summary>
			/// ������Ϣ4
			/// </summary>
			public string SVal4 { get; set; }
			/// <summary>
			/// ������Ϣ5
			/// </summary>
			public string SVal5 { get; set; }
			/// <summary>
			/// ������Ϣ6
			/// </summary>
			public string SVal6 { get; set; }
			/// <summary>
			/// ������Ϣ7
			/// </summary>
			public string SVal7 { get; set; }
			/// <summary>
			/// ������Ϣ8
			/// </summary>
			public string SVal8 { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int? ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
		}

	}
}