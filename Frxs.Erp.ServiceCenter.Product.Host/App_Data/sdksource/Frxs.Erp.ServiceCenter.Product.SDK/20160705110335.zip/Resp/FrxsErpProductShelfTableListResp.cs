/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Shelf.TableList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ShelfTableListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Shelf.TableList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ShelfTableListRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.Shelf]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpProductShelfTableListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductShelfTableListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductShelfTableListRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<Shelf> ItemList { get; set; }
		}

		/// <summary>
		/// �ֿ���ܱ�Shelfʵ����
		/// </summary>
		public class Shelf
		{
			/// <summary>
			/// ID(����)
			/// </summary>
			public int ShelfID { get; set; }
			/// <summary>
			/// ��λ���(ͬһ���ֿⲻ���ظ�)
			/// </summary>
			public string ShelfCode { get; set; }
			/// <summary>
			/// ��������ID(ShelfArea.ShelfAreaID)
			/// </summary>
			public int ShelfAreaID { get; set; }
			/// <summary>
			/// ��λ����(0:�洢;1:)
			/// </summary>
			public string ShelfType { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ״̬(0:����;1:����)
			/// </summary>
			public string Status { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// �����޸�ɾ��ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸�ɾ���û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸�ɾ���û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// �ֿ�����
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string ShelfAreaName { get; set; }
			/// <summary>
			/// ״̬
			/// </summary>
			public string StatusStr { get; set; }
		}

	}
}