/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Products.WarehousePrice.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductWarehousePriceGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Products.WarehousePrice.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.ProductWarehousePriceGetAction+ProductWarehousePriceGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Actions.ProductWarehousePriceGetAction+ProductWarehousePriceGetActionResponseDto]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��Ʒ�ֿ�۸��ȡ�б�
	/// </summary>
	public class FrxsErpProductProductsWarehousePriceGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public List<FrxsErpProductProductsWarehousePriceGetRespData> Data { get; set; }

		/// <summary>
		/// ���͵�����
		/// </summary>
		public class FrxsErpProductProductsWarehousePriceGetRespData
		{
			/// <summary>
			/// ��Ʒ���
			/// </summary>
			public int ProdcutId { get; set; }
			/// <summary>
			/// �ֿ���Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// �ֿ�ID
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ�����
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// ��Ӧ��ID
			/// </summary>
			public int VendorID { get; set; }
			/// <summary>
			/// ����Ӧ��
			/// </summary>
			public string VendorName { get; set; }
			/// <summary>
			/// �ֿ���
			/// </summary>
			public decimal WStock { get; set; }
			/// <summary>
			/// ������
			/// </summary>
			public decimal BuyPrice { get; set; }
			/// <summary>
			/// �����ŵ����ۼ�
			/// </summary>
			public decimal MarketPrice { get; set; }
			/// <summary>
			/// ������
			/// </summary>
			public decimal SalePrice { get; set; }
		}

	}
}