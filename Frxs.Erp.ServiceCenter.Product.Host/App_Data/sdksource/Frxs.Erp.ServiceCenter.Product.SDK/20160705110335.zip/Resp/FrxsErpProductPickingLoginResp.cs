/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.PickingLogin
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.PickingLoginAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.PickingLogin
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.PickingLoginAction+PickingLoginActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.PickingLoginAction+PickingLoginActionResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ����ӿ�-��¼
	/// </summary>
	public class FrxsErpProductPickingLoginResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductPickingLoginRespData Data { get; set; }

		/// <summary>
		/// �ӿڵ��÷��ز���
		/// </summary>
		public class FrxsErpProductPickingLoginRespData
		{
			/// <summary>
			/// Ա�����
			/// </summary>
			public int EmpID { get; set; }
			/// <summary>
			/// �û�����
			/// </summary>
			public string EmpName { get; set; }
			/// <summary>
			/// �û�����(1:���Ա;2:����Ա;3:װ��Ա;4:�ɹ�Ա)
			/// </summary>
			public int UserType { get; set; }
			/// <summary>
			/// ��λ���
			/// </summary>
			public int ShelfID { get; set; }
			/// <summary>
			/// �������
			/// </summary>
			public int ShelfAreaID { get; set; }
			/// <summary>
			/// ���ֱ��
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ��������
			/// </summary>
			public string ShelfAreaCode { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string ShelfAreaName { get; set; }
			/// <summary>
			/// ���APP�����ʾ��
			/// </summary>
			public int PickingMaxRecord { get; set; }
			/// <summary>
			/// �Ƿ����鳤
			/// </summary>
			public int IsMaster { get; set; }
			/// <summary>
			/// �û������ֻ�����
			/// </summary>
			public string UserMobile { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// �����ֿ���
			/// </summary>
			public int WarehouseWID { get; set; }
		}

	}
}