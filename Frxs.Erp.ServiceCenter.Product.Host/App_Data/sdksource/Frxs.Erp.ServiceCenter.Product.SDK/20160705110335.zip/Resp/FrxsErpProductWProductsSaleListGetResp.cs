/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.Sale.List.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsSaleListGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.Sale.List.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsSaleListGetAction+WProductsSaleListGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.WProductsSaleQueryModel]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ�ֿ����ͼ۸��б�
	/// </summary>
	public class FrxsErpProductWProductsSaleListGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductWProductsSaleListGetRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductWProductsSaleListGetRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<WProductsSaleQueryModel> ItemList { get; set; }
		}

		/// <summary>
		/// ���ͼ۸��ѯ
		/// </summary>
		public class WProductsSaleQueryModel
		{
			/// <summary>
			/// ��Ʒ���
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��ƷSKU
			/// </summary>
			public string SKU { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// ���͵�λ
			/// </summary>
			public string SaleUnit { get; set; }
			/// <summary>
			/// ��װ����
			/// </summary>
			public decimal PackingQty { get; set; }
			/// <summary>
			/// ���ͼ۸�
			/// </summary>
			public decimal SalePrice { get; set; }
			/// <summary>
			/// ��С��λ
			/// </summary>
			public string Unit { get; set; }
			/// <summary>
			/// ��С��λ�۸�
			/// </summary>
			public decimal UnitPrice { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string BarCode { get; set; }
			/// <summary>
			/// �ŵ��浥λ�����(%)
			/// </summary>
			public decimal ShopAddPerc { get; set; }
			/// <summary>
			/// �ŵ��浥λ����
			/// </summary>
			public decimal ShopPoint { get; set; }
			/// <summary>
			/// ��浥λ��Ч���֣�˾�����ŵ꼨Ч��)
			/// </summary>
			public decimal BasePoint { get; set; }
			/// <summary>
			/// ��浥λ��������(��Ӧ��) (%)
			/// </summary>
			public decimal VendorPerc1 { get; set; }
			/// <summary>
			/// ��浥λ�ִ�����(��Ӧ��)(%)
			/// </summary>
			public decimal VendorPerc2 { get; set; }
			/// <summary>
			/// �����
			/// </summary>
			public decimal WStock { get; set; }
			/// <summary>
			/// �ɹ��۸�
			/// </summary>
			public decimal BuyPrice { get; set; }
			/// <summary>
			/// ��Ʒ״̬
			/// </summary>
			public int WStatus { get; set; }
		}

	}
}