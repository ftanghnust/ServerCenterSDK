/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Products.Attributes.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsAttributesGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Products.Attributes.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ProductsAttributesGetRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsAttributesGetAction+ProductsAttributesGetResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡһ����Ʒ���еĹ�����Ժ͹��ͼƬ��Ϣ
	/// </summary>
	public class FrxsErpProductProductsAttributesGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductProductsAttributesGetRespData Data { get; set; }

		/// <summary>
		/// ���ز���
		/// </summary>
		public class FrxsErpProductProductsAttributesGetRespData
		{
			/// <summary>
			/// �Ƿ����ͼƬ
			/// </summary>
			public int IsMutiAttribute { get; set; }
			/// <summary>
			/// ��Ʒ���
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ����ͼ����Ʒ���
			/// </summary>
			public string Txtkid { get; set; }
			/// <summary>
			/// ĸ��Ʒ��ţ�����ĸ��Ʒ��Ϣ��
			/// </summary>
			public int BaseProductId { get; set; }
			/// <summary>
			/// �Ƿ�Ϊĸ��Ʒ
			/// </summary>
			public int IsBaseProductId { get; set; }
			/// <summary>
			/// ��Ʒ���ͼƬ
			/// </summary>
			public ProductsAttributesPicture ProductsAttributesPicture { get; set; }
			/// <summary>
			/// ��Ʒ����б�
			/// </summary>
			public IEnumerable<ProductsAttributes> ProductsAttributes { get; set; }
		}

		/// <summary>
		/// ProductsAttributesPictureʵ����
		/// </summary>
		public class ProductsAttributesPicture
		{
			/// <summary>
			/// ��ƷID(Product.ProductId)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ԭͼ800*800·��
			/// </summary>
			public string ImageUrlOrg { get; set; }
			/// <summary>
			/// zipΪ400*400��ͼ·��
			/// </summary>
			public string ImageUrl400x400 { get; set; }
			/// <summary>
			/// zipΪ200*200��ͼ·��
			/// </summary>
			public string ImageUrl200x200 { get; set; }
			/// <summary>
			/// zipΪ120*120��ͼ·��
			/// </summary>
			public string ImageUrl120x120 { get; set; }
			/// <summary>
			/// zipΪ60*60��ͼ·��
			/// </summary>
			public string ImageUrl60x60 { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
		}

		/// <summary>
		/// ��Ʒ��������ֵ��ProductsAttributesʵ����
		/// </summary>
		public class ProductsAttributes
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int ID { get; set; }
			/// <summary>
			/// ��ƷID(Product.ProductId)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ���Ա�ID(Attribute.AttributeId��
			/// </summary>
			public int AttributeId { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string AttributeName { get; set; }
			/// <summary>
			/// ����ֵ��ID(AttributeValues.ValueId��
			/// </summary>
			public int ValuesId { get; set; }
			/// <summary>
			/// ֵ
			/// </summary>
			public string ValueStr { get; set; }
			/// <summary>
			/// �����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
		}

	}
}