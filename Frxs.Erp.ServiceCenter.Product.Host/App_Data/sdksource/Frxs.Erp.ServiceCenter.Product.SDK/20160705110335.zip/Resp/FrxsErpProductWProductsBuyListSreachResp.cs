/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProductsBuy.ListSreach
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsBuyListSreachAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProductsBuy.ListSreach
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsBuyListSreachAction+WProductsBuyListSreachRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.IList`1[Frxs.Erp.ServiceCenter.Product.Model.WProductsBuyQModel]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ������Ʒ��Ϣ
	/// </summary>
	public class FrxsErpProductWProductsBuyListSreachResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public IList<FrxsErpProductWProductsBuyListSreachRespData> Data { get; set; }

		/// <summary>
		/// WProductsBuyʵ����
		/// </summary>
		public class FrxsErpProductWProductsBuyListSreachRespData
		{
			/// <summary>
			/// ����ID(WProduct.WProductID 1��1�Ĺ�ϵ)
			/// </summary>
			public long WProductID { get; set; }
			/// <summary>
			/// �ֿ�ID(һ��)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ��ƷID(product.ProductID)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��浥λ�ɹ��۸�
			/// </summary>
			public decimal BuyPrice { get; set; }
			/// <summary>
			/// ��(�ɹ�)��λ�ܲ�����Ʒ�൥λID(ProductsUnit.ID)
			/// </summary>
			public int BigProductsUnitID { get; set; }
			/// <summary>
			/// ��(�ɹ�)��λ��װ��(������� ѡ�����͵�λʱ,ͬ���ñ�,û��ʱ��ֵΪ��浥λ)
			/// </summary>
			public decimal BigPackingQty { get; set; }
			/// <summary>
			/// ��(�ɹ�)��λ(������� ѡ�����͵�λʱ,ͬ���ñ�,û��ʱ��ֵΪ1)
			/// </summary>
			public string BigUnit { get; set; }
			/// <summary>
			/// ��Ʒ����Ӧ��ID(Vendor.VendorID)
			/// </summary>
			public int VendorID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string VendorCode { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string VendorName { get; set; }
		}

	}
}