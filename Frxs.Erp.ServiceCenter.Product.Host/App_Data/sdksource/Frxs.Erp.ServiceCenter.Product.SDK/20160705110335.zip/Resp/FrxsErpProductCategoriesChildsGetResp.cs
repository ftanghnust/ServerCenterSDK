/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Categories.Childs.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.CategoriesChildsGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Categories.Childs.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.CategoriesChildsGetAction+CategoriesChildsGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Model.Categories]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ�������༯�ϣ����ط�����󼯺ϣ����������������ȼ�����
	/// </summary>
	public class FrxsErpProductCategoriesChildsGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public List<FrxsErpProductCategoriesChildsGetRespData> Data { get; set; }

		/// <summary>
		/// Categoriesʵ����
		/// </summary>
		public class FrxsErpProductCategoriesChildsGetRespData
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int CategoryId { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string Name { get; set; }
			/// <summary>
			/// ��ʾ˳��
			/// </summary>
			public int DisplaySequence { get; set; }
			/// <summary>
			/// �㼶����ID
			/// </summary>
			public int ParentCategoryId { get; set; }
			/// <summary>
			/// ����(0:����;1:һ��;2:����;3:����)
			/// </summary>
			public int Depth { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��(0:δɾ��;1:��ɾ��)
			/// </summary>
			public int IsDeleted { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
		}

	}
}