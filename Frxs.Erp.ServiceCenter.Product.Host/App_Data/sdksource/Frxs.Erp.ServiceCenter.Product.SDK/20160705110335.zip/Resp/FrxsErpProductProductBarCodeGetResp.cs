/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ProductBarCode.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsBarCodeGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ProductBarCode.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsBarCodeGetAction+ProductsBarCodesGetAllRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.ProductsBarCodeGetAction+ProductsBarCodesGetAllResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ��Ʒ��������ӿ�
	/// </summary>
	public class FrxsErpProductProductBarCodeGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductProductBarCodeGetRespData Data { get; set; }

		/// <summary>
		/// �������
		/// </summary>
		public class FrxsErpProductProductBarCodeGetRespData
		{
			/// <summary>
			/// ��ƷID(product.ProductId)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��Ʒ���������б�
			/// </summary>
			public IList<ProductsBarCodes> ProductsBarCodes { get; set; }
		}

		/// <summary>
		/// ��Ʒ��������ProductsBarCodesʵ����
		/// </summary>
		public class ProductsBarCodes
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int ID { get; set; }
			/// <summary>
			/// ��ƷID(product.ProductId)
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string BarCode { get; set; }
			/// <summary>
			/// ����(�̶���1��ʼ;1����������)
			/// </summary>
			public int SerialNumber { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
		}

	}
}