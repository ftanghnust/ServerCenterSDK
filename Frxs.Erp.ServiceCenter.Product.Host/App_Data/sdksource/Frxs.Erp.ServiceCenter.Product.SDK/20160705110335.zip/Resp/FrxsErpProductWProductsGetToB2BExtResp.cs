/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.Get.ToB2BExt
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsGetToB2BExtAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.Get.ToB2BExt
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsGetToB2BExtAction+WProductsGetToB2BExtActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsGetToB2BExtAction+WProductsGetToB2BExtActionResponsetDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ������Ʒ��Ϣ(�����޹�)��������ҳ�Ͳ���ҳ
	/// </summary>
	public class FrxsErpProductWProductsGetToB2BExtResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductWProductsGetToB2BExtRespData Data { get; set; }

		/// <summary>
		/// ���������Ϣ
		/// </summary>
		public class FrxsErpProductWProductsGetToB2BExtRespData
		{
			/// <summary>
			/// �ֿ���Ʒ����
			/// </summary>
			public IList<WProductExt> ItemList { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public int TotalRecords { get; set; }
		}

		/// <summary>
		/// ��չ
		/// </summary>
		public class WProductExt
		{
			/// <summary>
			/// ���������ܼۣ��������ͼ� * ��װ����
			/// </summary>
			public decimal BigSalePrice { get; set; }
			/// <summary>
			/// WProductsBuy ����
			/// </summary>
			public decimal BuyPrice { get; set; }
			/// <summary>
			/// ���ͻ��ֶ����ܼۣ��������ͼ� * ��װ����
			/// </summary>
			public decimal BigShopPoint { get; set; }
			/// <summary>
			/// �̿���ϸͼƬ400x400
			/// </summary>
			public string ImageUrl400x400 { get; set; }
			/// <summary>
			/// �̿���ϸͼƬ200x200
			/// </summary>
			public string ImageUrl200x200 { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// MaxOrderQty
			/// </summary>
			public decimal MaxOrderQty { get; set; }
			/// <summary>
			/// SKU
			/// </summary>
			public string SKU { get; set; }
			/// <summary>
			/// BarCode
			/// </summary>
			public string BarCode { get; set; }
			/// <summary>
			/// CategoryName1
			/// </summary>
			public string CategoryName1 { get; set; }
			/// <summary>
			/// CategoryName2
			/// </summary>
			public string CategoryName2 { get; set; }
			/// <summary>
			/// CategoryName3
			/// </summary>
			public string CategoryName3 { get; set; }
			/// <summary>
			/// CategoryId1
			/// </summary>
			public int CategoryId1 { get; set; }
			/// <summary>
			/// CategoryId2
			/// </summary>
			public int CategoryId2 { get; set; }
			/// <summary>
			/// CategoryId3
			/// </summary>
			public int CategoryId3 { get; set; }
			/// <summary>
			/// ��λ����ID
			/// </summary>
			public int ShelfAreaID { get; set; }
			/// <summary>
			/// ��λ�������
			/// </summary>
			public string ShelfAreaCode { get; set; }
			/// <summary>
			/// ��λ����
			/// </summary>
			public string ShelfCode { get; set; }
			/// <summary>
			/// ��λ��������
			/// </summary>
			public string ShelfAreaName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? PromotionShopPoint { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? VendorID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string VendorName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string VendorCode { get; set; }
			/// <summary>
			/// �ɹ�ԱID
			/// </summary>
			public string EmpID { get; set; }
			/// <summary>
			/// �ɹ�Ա
			/// </summary>
			public string EmpName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public long WProductID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ProductName2 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int WStatus { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string Unit { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? SalePrice { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? MarketPrice { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string MarketUnit { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? BigProductsUnitID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? BigPackingQty { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string BigUnit { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? ShelfID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? ShopAddPerc { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? ShopPoint { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? BasePoint { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? VendorPerc1 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal? VendorPerc2 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string SaleBackFlag { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? BackDays { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? CreateUserID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public DateTime? ModifyTime { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? ModifyUserID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ModifyUserName { get; set; }
		}

	}
}