/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.SysArea.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.SysAreaGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.SysArea.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.SysAreaGetAction+SysAreaGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.IList`1[Frxs.Erp.ServiceCenter.Product.Model.SysArea]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡϵͳ��������Ϣ
	/// </summary>
	public class FrxsErpProductSysAreaGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public IList<FrxsErpProductSysAreaGetRespData> Data { get; set; }

		/// <summary>
		/// SysAreaʵ����
		/// </summary>
		public class FrxsErpProductSysAreaGetRespData
		{
			/// <summary>
			/// ����ID(�����������)
			/// </summary>
			public int AreaID { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string AreaName { get; set; }
			/// <summary>
			/// ���򼶱�(0:ȫ��;1:ʡ;2:��;3:��)
			/// </summary>
			public int Level { get; set; }
			/// <summary>
			/// ����ID
			/// </summary>
			public int? ParentID { get; set; }
			/// <summary>
			/// �����޸�ɾ��ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸�ɾ���û�ID
			/// </summary>
			public int? ModifyUserID { get; set; }
			/// <summary>
			/// ����޸�ɾ���û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? SyncFale { get; set; }
		}

	}
}