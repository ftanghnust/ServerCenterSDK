/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Vendor.LastBuy.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.Vendor.VerdorLastBuyGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Vendor.LastBuy.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.Vendor.VerdorLastBuyGetAction+VerdorLastBuyActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Model.VendorLastBuy]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡĳ���ֿ��µ���Ʒ���һ�ν����Ĺ�Ӧ����Ϣ����
	/// </summary>
	public class FrxsErpProductVendorLastBuyGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public List<FrxsErpProductVendorLastBuyGetRespData> Data { get; set; }

		/// <summary>
		/// ĳ��Ʒ�����һ�ν����Ĺ�Ӧ����Ϣ
		/// </summary>
		public class FrxsErpProductVendorLastBuyGetRespData
		{
			/// <summary>
			/// �ֿ�ID
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ��ƷID
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��Ӧ��ID
			/// </summary>
			public int VendorID { get; set; }
			/// <summary>
			/// ��Ӧ�̱��
			/// </summary>
			public string VendorCode { get; set; }
			/// <summary>
			/// ��Ӧ������
			/// </summary>
			public string VendorName { get; set; }
			/// <summary>
			/// ���²ɹ����ʱ��
			/// </summary>
			public DateTime? LastBuyTime { get; set; }
		}

	}
}