/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Vendor.Save
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.Vendor.VendorSaveAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Vendor.Save
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.Vendor.VendorSaveActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Model.Vendor
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ��Ӧ���б�
	/// </summary>
	public class FrxsErpProductVendorSaveResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductVendorSaveRespData Data { get; set; }

		/// <summary>
		/// ��Ӧ�̱�Vendorʵ����
		/// </summary>
		public class FrxsErpProductVendorSaveRespData
		{
			/// <summary>
			/// ��Ӧ������(VendorType.VendorTypeID)
			/// </summary>
			public string VendorTypeName { get; set; }
			/// <summary>
			/// ���㷽ʽ( �����ֵ�: VendorSettleTimeType)
			/// </summary>
			public string SettleTimeTypeName { get; set; }
			/// <summary>
			/// ״̬(1:����;0:����)
			/// </summary>
			public string StatusName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string CreditLevelName { get; set; }
			/// <summary>
			/// ��ֿ������ϵ����
			/// </summary>
			public string VendorWarehouseDatas { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string PaymentDateTypeName { get; set; }
			/// <summary>
			/// ��Ӧ�̷���ID
			/// </summary>
			public int VendorID { get; set; }
			/// <summary>
			/// ��Ӧ�̱��
			/// </summary>
			public string VendorCode { get; set; }
			/// <summary>
			/// ��Ӧ������
			/// </summary>
			public string VendorName { get; set; }
			/// <summary>
			/// ��Ӧ�̼��
			/// </summary>
			public string VendorShortName { get; set; }
			/// <summary>
			/// ��Ӧ������(VendorType.VendorTypeID)
			/// </summary>
			public int VendorTypeID { get; set; }
			/// <summary>
			/// ��ϵ������
			/// </summary>
			public string LinkMan { get; set; }
			/// <summary>
			/// ��ϵ�绰
			/// </summary>
			public string Telephone { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string Fax { get; set; }
			/// <summary>
			/// ״̬(1:����;0:����)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// ��ҵ����
			/// </summary>
			public string LegalPerson { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string Email { get; set; }
			/// <summary>
			/// ��˾��ַ
			/// </summary>
			public string WebUrl { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string Region { get; set; }
			/// <summary>
			/// ���㷽ʽ( �����ֵ�: VendorSettleTimeType)
			/// </summary>
			public string SettleTimeType { get; set; }
			/// <summary>
			/// ��Ӧ�̼���(�����ֵ�: VendorLevel; A:A��;B:B��;C:C��)
			/// </summary>
			public string CreditLevel { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string AreaPrincipal { get; set; }
			/// <summary>
			/// ʡ
			/// </summary>
			public int? ProvinceID { get; set; }
			/// <summary>
			/// ��
			/// </summary>
			public int? CityID { get; set; }
			/// <summary>
			/// ��
			/// </summary>
			public int? RegionID { get; set; }
			/// <summary>
			/// ��ַ
			/// </summary>
			public string Address { get; set; }
			/// <summary>
			/// ��ַȫ��
			/// </summary>
			public string FullAddress { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��(0:δɾ��;1:��ɾ��);
			/// </summary>
			public int IsDeleted { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string PaymentDateType { get; set; }
			/// <summary>
			/// ��չ��ʶ1
			/// </summary>
			public string VExt1 { get; set; }
			/// <summary>
			/// ��չ��ʶ2
			/// </summary>
			public string VExt2 { get; set; }
		}

	}
}