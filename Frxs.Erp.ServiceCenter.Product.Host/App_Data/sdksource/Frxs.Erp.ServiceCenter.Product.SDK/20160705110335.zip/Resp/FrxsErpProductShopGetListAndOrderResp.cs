/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Shop.GetListAndOrder
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ResponseDto.Shop.ShopGetListAndOrderAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Shop.GetListAndOrder
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ShopGetListAndOrderRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.IList`1[Frxs.Erp.ServiceCenter.Product.Model.ShopExt]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ�ܲ���̨�ŵ���Ϣ����(�����ŵ�)
	/// </summary>
	public class FrxsErpProductShopGetListAndOrderResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public IList<FrxsErpProductShopGetListAndOrderRespData> Data { get; set; }

		/// <summary>
		/// �����ŵ��ŵ�
		/// </summary>
		public class FrxsErpProductShopGetListAndOrderRespData
		{
			/// <summary>
			/// �ŵ꼶��(�����ֵ�: ShopLevel; A:A��;B:B��;C:C��)
			/// </summary>
			public string CreditLevel { get; set; }
			/// <summary>
			/// �ŵ�ID
			/// </summary>
			public int ShopID { get; set; }
			/// <summary>
			/// �ŵ���
			/// </summary>
			public string ShopCode { get; set; }
			/// <summary>
			/// �ŵ�����(0:���˵�;1:ǩԼ��;)
			/// </summary>
			public int ShopType { get; set; }
			/// <summary>
			/// �ŵ�����(0:���˵�;1:ǩԼ��;)
			/// </summary>
			public string ShopTypeStr { get; set; }
			/// <summary>
			/// �ŵ�����
			/// </summary>
			public string ShopName { get; set; }
			/// <summary>
			/// �ŵ��ʺ�(XSUser.Account)
			/// </summary>
			public string ShopAccount { get; set; }
			/// <summary>
			/// ���Ͳֿ�ID(WarehouseInfo.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ŵ���ϵ������
			/// </summary>
			public string LinkMan { get; set; }
			/// <summary>
			/// �ŵ���ϵ�绰
			/// </summary>
			public string Telephone { get; set; }
			/// <summary>
			/// ״̬(1:����;0:����)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// ��ַ
			/// </summary>
			public string Address { get; set; }
			/// <summary>
			/// ��ַȫ��
			/// </summary>
			public string FullAddress { get; set; }
			/// <summary>
			/// ״̬(1:����;0:����)
			/// </summary>
			public string StatusStr { get; set; }
			/// <summary>
			/// ������
			/// </summary>
			public string OrderId { get; set; }
			/// <summary>
			/// ��·ID WarehouseLine.LineID
			/// </summary>
			public int LineID { get; set; }
			/// <summary>
			/// ��·���� WarehouseLine.LineName
			/// </summary>
			public string LineName { get; set; }
			/// <summary>
			/// ��·���
			/// </summary>
			public string LineCode { get; set; }
			/// <summary>
			/// ��·���
			/// </summary>
			public string DeliverWeek { get; set; }
			/// <summary>
			/// ��������1
			/// </summary>
			public int SendW1 { get; set; }
			/// <summary>
			/// ��������2
			/// </summary>
			public int SendW2 { get; set; }
			/// <summary>
			/// ��������3
			/// </summary>
			public int SendW3 { get; set; }
			/// <summary>
			/// ��������4
			/// </summary>
			public int SendW4 { get; set; }
			/// <summary>
			/// ��������5
			/// </summary>
			public int SendW5 { get; set; }
			/// <summary>
			/// ��������6
			/// </summary>
			public int SendW6 { get; set; }
			/// <summary>
			/// ��������7
			/// </summary>
			public int SendW7 { get; set; }
		}

	}
}