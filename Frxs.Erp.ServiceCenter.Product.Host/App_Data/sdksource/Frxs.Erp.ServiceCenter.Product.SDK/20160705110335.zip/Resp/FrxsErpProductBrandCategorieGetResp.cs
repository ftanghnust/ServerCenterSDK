/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.BrandCategorie.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.BrandCategorieListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.BrandCategorie.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.BrandCategorieListAction+BrandCategorieListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.BrandCategories]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// Ʒ�Ʒ����б�
	/// </summary>
	public class FrxsErpProductBrandCategorieGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductBrandCategorieGetRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductBrandCategorieGetRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<BrandCategories> ItemList { get; set; }
		}

		/// <summary>
		/// ��ԭ��Buymoo_BrandCategories ���ƽṹ������BrandCategoriesʵ����
		/// </summary>
		public class BrandCategories
		{
			/// <summary>
			/// Ʒ��ID
			/// </summary>
			public int BrandId { get; set; }
			/// <summary>
			/// Ʒ������
			/// </summary>
			public string BrandName { get; set; }
			/// <summary>
			/// Ʒ��Ӣ������
			/// </summary>
			public string BrandEnName { get; set; }
			/// <summary>
			/// Ʒ��URL
			/// </summary>
			public string Logo { get; set; }
			/// <summary>
			/// ��ʾ˳��
			/// </summary>
			public int DisplaySequence { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��(0:δɾ��;1:��ɾ��)
			/// </summary>
			public int IsDeleted { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
		}

	}
}