/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.WProducts.WaitAdd.List.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsWaitAddListGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.WProducts.WaitAdd.List.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.WProductsWaitAddListGetAction+WProductsWaitAddListGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.WProductsWaitAddListModel]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��δ���뵽�ֿ��̨����Ʒ�б�
	/// </summary>
	public class FrxsErpProductWProductsWaitAddListGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductWProductsWaitAddListGetRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductWProductsWaitAddListGetRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<WProductsWaitAddListModel> ItemList { get; set; }
		}

		/// <summary>
		/// �ȴ�������Ʒ��ѯ����
		/// </summary>
		public class WProductsWaitAddListModel
		{
			/// <summary>
			/// ��ƷID
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ERP����
			/// </summary>
			public string SKU { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public int CategoryId1 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string CategoryName1 { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public int CategoryId2 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string CategoryName2 { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public int CategoryId3 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string CategoryName3 { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName2 { get; set; }
			/// <summary>
			/// �������
			/// </summary>
			public string Attributes { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string BarCode { get; set; }
			/// <summary>
			/// ��浥λ
			/// </summary>
			public string Unit { get; set; }
		}

	}
}