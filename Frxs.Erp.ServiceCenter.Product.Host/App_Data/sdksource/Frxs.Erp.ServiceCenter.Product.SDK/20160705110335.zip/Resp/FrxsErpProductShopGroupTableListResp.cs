/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.ShopGroup.TableList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ShopGroupTableListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.ShopGroup.TableList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.ShopGroupTableListAction+ShopGroupTableListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.ShopGroup]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// �ŵ�Ⱥ�� ��ѯ����
	/// </summary>
	public class FrxsErpProductShopGroupTableListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductShopGroupTableListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductShopGroupTableListRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<ShopGroup> ItemList { get; set; }
		}

		/// <summary>
		/// �����ŵ�Ⱥ���ShopGroupʵ����
		/// </summary>
		public class ShopGroup
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int GroupID { get; set; }
			/// <summary>
			/// Ⱥ����
			/// </summary>
			public string GroupCode { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// Ⱥ������
			/// </summary>
			public string GroupName { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��(0:δɾ��;1: ��ɾ��)
			/// </summary>
			public int IsDeleted { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// �ŵ�����
			/// </summary>
			public int ShopNum { get; set; }
			/// <summary>
			/// �ŵ꼯��
			/// </summary>
			public IList<ShopGroupDetails> List { get; set; }
		}

		/// <summary>
		/// �ŵ�Ⱥ����ϸ��ShopGroupDetailsʵ����
		/// </summary>
		public class ShopGroupDetails
		{
			/// <summary>
			/// ����ID
			/// </summary>
			public int ID { get; set; }
			/// <summary>
			/// ����ID
			/// </summary>
			public int GroupID { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ŵ�ID
			/// </summary>
			public int ShopID { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// �ŵ���
			/// </summary>
			public string ShopCode { get; set; }
			/// <summary>
			/// �ŵ�����
			/// </summary>
			public string ShopName { get; set; }
			/// <summary>
			/// �ŵ��ַ
			/// </summary>
			public string FullAddress { get; set; }
		}

	}
}