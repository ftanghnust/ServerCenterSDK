/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Warehouse.TableList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.Warehouse.WarehouseTableListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Warehouse.TableList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.WarehouseTableListRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.Warehouse]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// �ֿ��б���ѯ ������ʾ
	/// </summary>
	public class FrxsErpProductWarehouseTableListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductWarehouseTableListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductWarehouseTableListRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<Warehouse> ItemList { get; set; }
		}

		/// <summary>
		/// �ֿ�����Warehouseʵ����
		/// </summary>
		public class Warehouse
		{
			/// <summary>
			/// �ֿ�ID(��1000��ʼ���)
			/// </summary>
			public int? WID { get; set; }
			/// <summary>
			/// �ֿ���(Ψһ)
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// �ֿ�����
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// �ֿ⼶��(0:�ܲ�[Ԥ��];1:�ֿ�;2:�ֿ��ӻ�������/�˻�])
			/// </summary>
			public int? WLevel { get; set; }
			/// <summary>
			/// �ӻ�������(0:�˻�;1:������;)
			/// </summary>
			public int? WSubType { get; set; }
			/// <summary>
			/// ����ID
			/// </summary>
			public int? ParentWID { get; set; }
			/// <summary>
			/// ��ϵ�绰
			/// </summary>
			public string WTel { get; set; }
			/// <summary>
			/// ��ϵ������
			/// </summary>
			public string WContact { get; set; }
			/// <summary>
			/// ʡ
			/// </summary>
			public int? ProvinceID { get; set; }
			/// <summary>
			/// ��
			/// </summary>
			public int? CityID { get; set; }
			/// <summary>
			/// ��
			/// </summary>
			public int? RegionID { get; set; }
			/// <summary>
			/// ��ַ
			/// </summary>
			public string WAddress { get; set; }
			/// <summary>
			/// ȫ�Ƶ�ַ
			/// </summary>
			public string WFullAddress { get; set; }
			/// <summary>
			/// 400�ͷ��绰
			/// </summary>
			public string WCustomerServiceTel { get; set; }
			/// <summary>
			/// �˻����绰
			/// </summary>
			public string THBTel { get; set; }
			/// <summary>
			/// �����ҵ绰
			/// </summary>
			public string CWTel { get; set; }
			/// <summary>
			/// ҵ����ѯ�绰1
			/// </summary>
			public string YW1Tel { get; set; }
			/// <summary>
			/// ҵ����ѯ�绰2
			/// </summary>
			public string YW2Tel { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// �Ƿ��ѱ�����(0:δ����;1���Ѷ���)
			/// </summary>
			public int? IsFreeze { get; set; }
			/// <summary>
			/// �Ƿ��ѱ�ɾ��(0:δɾ��;1����ɾ��)
			/// </summary>
			public int? IsDeleted { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û� ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// �޸�ʱ��
			/// </summary>
			public DateTime ModityTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModityUserID { get; set; }
			/// <summary>
			/// ����޸��ü�����
			/// </summary>
			public string ModityUserName { get; set; }
			/// <summary>
			/// ����״̬(0:δ����;1���Ѷ���)
			/// </summary>
			public string FreezeStatus { get; set; }
			/// <summary>
			/// ��Ͻ�Ĳֿ��ӻ���������
			/// </summary>
			public int SubNum { get; set; }
			/// <summary>
			/// ��Ͻ�ŵ�����
			/// </summary>
			public int ShopNum { get; set; }
		}

	}
}