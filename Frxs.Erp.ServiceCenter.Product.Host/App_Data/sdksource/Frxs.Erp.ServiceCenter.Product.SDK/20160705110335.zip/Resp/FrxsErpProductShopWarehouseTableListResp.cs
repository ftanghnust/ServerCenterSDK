/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Shop.Warehouse.TableList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ResponseDto.Shop.ShopWhTableListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Shop.Warehouse.TableList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.ShopWhTableListRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Product.Model.Shop]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ �ֿ��̨ �ŵ��ѯ�б����
	/// </summary>
	public class FrxsErpProductShopWarehouseTableListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductShopWarehouseTableListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductShopWarehouseTableListRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<Shop> ItemList { get; set; }
		}

		/// <summary>
		/// �ŵ����ϱ�Shopʵ����
		/// </summary>
		public class Shop
		{
			/// <summary>
			/// �ŵ�ID
			/// </summary>
			public int ShopID { get; set; }
			/// <summary>
			/// �ŵ���
			/// </summary>
			public string ShopCode { get; set; }
			/// <summary>
			/// �ŵ�����(0:���˵�;1:ǩԼ��;)
			/// </summary>
			public int ShopType { get; set; }
			/// <summary>
			/// �ŵ�����
			/// </summary>
			public string ShopName { get; set; }
			/// <summary>
			/// �ŵ��ʺ�(XSUser.Account)
			/// </summary>
			public string ShopAccount { get; set; }
			/// <summary>
			/// ���ʷ�ʽ(0:�ֽ� + �����ֵ�: ShopSettleType)
			/// </summary>
			public string SettleType { get; set; }
			/// <summary>
			/// ���Ͳֿ�ID(WarehouseInfo.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ŵ���ϵ������
			/// </summary>
			public string LinkMan { get; set; }
			/// <summary>
			/// �ŵ���ϵ�绰
			/// </summary>
			public string Telephone { get; set; }
			/// <summary>
			/// ״̬(1:����;0:����)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string LegalPerson { get; set; }
			/// <summary>
			/// ���㷽ʽ( �����ֵ�: ShopSettleTimeType)
			/// </summary>
			public string SettleTimeType { get; set; }
			/// <summary>
			/// �ŵ꼶��(�����ֵ�: ShopLevel; A:A��;B:B��;C:C��)
			/// </summary>
			public string CreditLevel { get; set; }
			/// <summary>
			/// ���ö��
			/// </summary>
			public double CreditAmt { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string AreaPrincipal { get; set; }
			/// <summary>
			/// ʡ
			/// </summary>
			public int ProvinceID { get; set; }
			/// <summary>
			/// ��
			/// </summary>
			public int CityID { get; set; }
			/// <summary>
			/// ��
			/// </summary>
			public int RegionID { get; set; }
			/// <summary>
			/// ��ַ
			/// </summary>
			public string Address { get; set; }
			/// <summary>
			/// ��ַȫ��
			/// </summary>
			public string FullAddress { get; set; }
			/// <summary>
			/// �ŵ����(ƽ����)
			/// </summary>
			public decimal ShopArea { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��(0:δɾ��;1:��ɾ��)
			/// </summary>
			public int IsDeleted { get; set; }
			/// <summary>
			/// γ�ȣ��ٶ�����)
			/// </summary>
			public string Latitude { get; set; }
			/// <summary>
			/// ���ȣ��ٶ�����)
			/// </summary>
			public string Longitude { get; set; }
			/// <summary>
			/// �ŵ��ۼƻ���
			/// </summary>
			public double TotalPoint { get; set; }
			/// <summary>
			/// �����ʺ�
			/// </summary>
			public string BankAccount { get; set; }
			/// <summary>
			/// ���п�������
			/// </summary>
			public string BankAccountName { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string BankType { get; set; }
			/// <summary>
			/// ����֤����
			/// </summary>
			public string CardID { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string RegionMaster { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û� ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// �޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// ״̬(1:����;0:����)
			/// </summary>
			public string StatusStr { get; set; }
			/// <summary>
			/// ��·ID WarehouseLine.LineID
			/// </summary>
			public int LineID { get; set; }
			/// <summary>
			/// ��·���� WarehouseLine.LineName
			/// </summary>
			public string LineName { get; set; }
			/// <summary>
			/// �������� WarehouseLine.SerialNumber
			/// </summary>
			public int SerialNumber { get; set; }
			/// <summary>
			/// �������� WarehouseLine.SerialNumber
			/// </summary>
			public string SerialNumberStr { get; set; }
		}

	}
}