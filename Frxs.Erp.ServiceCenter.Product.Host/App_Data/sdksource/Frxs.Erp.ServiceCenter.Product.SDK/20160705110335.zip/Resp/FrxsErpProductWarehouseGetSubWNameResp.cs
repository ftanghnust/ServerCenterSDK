/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Warehouse.GetSubWName
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.ResponseDto.Warehouse.WarehouseGetSubWNameAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Warehouse.GetSubWName
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.WarehouseGetSubWNameRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.Erp.ServiceCenter.Product.Model.SubWName]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ�ֿ��ӻ��������Ϣ
	/// </summary>
	public class FrxsErpProductWarehouseGetSubWNameResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public List<FrxsErpProductWarehouseGetSubWNameRespData> Data { get; set; }

		/// <summary>
		/// �ֿ��ӻ��������Ϣ ���������(�綩��)ʹ��
		/// </summary>
		public class FrxsErpProductWarehouseGetSubWNameRespData
		{
			/// <summary>
			/// �ֿ�ID
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ�����
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// �ֿ���
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// �ӻ���ID
			/// </summary>
			public int SubWID { get; set; }
			/// <summary>
			/// �ӻ������
			/// </summary>
			public string SubWCode { get; set; }
			/// <summary>
			/// �ӻ�������
			/// </summary>
			public string SUBWName { get; set; }
		}

	}
}