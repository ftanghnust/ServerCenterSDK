/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.Vendor.GetVendorWarehouse
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.Vendor.VendorGetVendorWarehouseAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.Vendor.GetVendorWarehouse
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.Vendor.VendorGetVendorWarehouseRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.IList`1[Frxs.Erp.ServiceCenter.Product.Model.WarehouseSelectModel]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ��Ӧ���б�
	/// </summary>
	public class FrxsErpProductVendorGetVendorWarehouseResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public IList<FrxsErpProductVendorGetVendorWarehouseRespData> Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductVendorGetVendorWarehouseRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int? ID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? VendorID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string WName { get; set; }
		}

	}
}