/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.VendorType.Get
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.Vendor.VendorTypeGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.VendorType.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.RequestDto.Vendor.VendorTypeGetRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Model.VendorType
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ѯ��ǰ��Ӧ������
	/// </summary>
	public class FrxsErpProductVendorTypeGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductVendorTypeGetRespData Data { get; set; }

		/// <summary>
		/// ��Ӧ������VendorTypeʵ����
		/// </summary>
		public class FrxsErpProductVendorTypeGetRespData
		{
			/// <summary>
			/// ��Ӧ�̷���ID
			/// </summary>
			public int VendorTypeID { get; set; }
			/// <summary>
			/// ��Ӧ�̷�������
			/// </summary>
			public string VendorTypeName { get; set; }
			/// <summary>
			/// �Ƿ�ɾ��(0:δɾ��;1:��ɾ��);
			/// </summary>
			public int IsDeleted { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
		}

	}
}