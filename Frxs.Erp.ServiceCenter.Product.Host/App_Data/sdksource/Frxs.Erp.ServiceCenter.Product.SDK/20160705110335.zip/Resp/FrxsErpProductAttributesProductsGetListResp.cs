/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 11:03:34
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Product.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Erp.Product.AttributesProducts.GetList
* ActionType:Frxs.Erp.ServiceCenter.Product.Actions.AttributesProductsGetListAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Product.AttributesProducts.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Product.Actions.AttributesProductsGetListAction+AttributesProductsGetListRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Product.Actions.AttributesProductsGetListAction+AttributesProductsGetListResponseDto
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Product.SDK.Resp
{
	/// <summary>
	/// ��ȡ������Ʒ
	/// </summary>
	public class FrxsErpProductAttributesProductsGetListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpProductAttributesProductsGetListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpProductAttributesProductsGetListRespData
		{
			/// <summary>
			/// �ܼ�¼��
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// ����ļ������ݣ��˴��������Ϊһ���������͵Ķ��󣬱��磺����,�б�
			/// </summary>
			public List<AttributesProducts> ItemList { get; set; }
			/// <summary>
			/// ����
			/// </summary>
			public string AttributeName { get; set; }
		}

		/// <summary>
		/// ��������Ʒ
		/// </summary>
		public class AttributesProducts
		{
			/// <summary>
			/// ��ƷID(����)SKUNumberService.IDȡ��
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// ��Ʒ����(0000001,0000002),�7������;Ψһ��SKUNumberService.IDȡ�ò�0)
			/// </summary>
			public string SKU { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// Erp����
			/// </summary>
			public string ErpCode { get; set; }
			/// <summary>
			/// ���ֵ
			/// </summary>
			public string ValueStr { get; set; }
		}

	}
}