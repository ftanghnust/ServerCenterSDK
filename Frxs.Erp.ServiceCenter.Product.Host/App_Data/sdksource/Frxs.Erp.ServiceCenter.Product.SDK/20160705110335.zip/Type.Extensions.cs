/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 2015/11/12 11:35:44
 * *******************************************************/
using System;

namespace Frxs.Erp.ServiceCenter.Product.SDK
{
    /// <summary>
    /// 
    /// </summary>
    internal static class TypeExtensions
    {
        /// <summary>
        /// ��ȡ����������Ϣ����������Ϊ��System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.IgnoreCase
        /// </summary>
        /// <param name="type">����</param>
        /// <param name="propertyName">�������ƣ����Դ�Сд</param>
        /// <returns></returns>
        public static System.Reflection.PropertyInfo GetPropertyInfo(this Type type, string propertyName)
        {
            return type.GetProperty(propertyName, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.IgnoreCase);
        }
    }
}
