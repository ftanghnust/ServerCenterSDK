/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-28 11:39:40
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.ID.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Id.XSOperatorLog.Write
* ActionType:Frxs.Erp.ServiceCenter.ID.Actions.XSOperatorLogWrite
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionAuthentication]
* AuthorName:
* CacheTime:0
* CanPackageToSDK:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Id.XSOperatorLog.Write
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.ID.Actions.XSOperatorLogWrite+XSOperatorLogWriteRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.ID.SDK.Resp
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpIdXSOperatorLogWriteResp : ResponseBase 
	{
		/// <summary>
		///  
		/// <summary>
		public int Data { get; set; }

	}
}