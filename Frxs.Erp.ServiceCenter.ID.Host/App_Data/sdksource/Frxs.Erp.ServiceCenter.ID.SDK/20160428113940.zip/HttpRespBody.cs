/*********************************************************
 * FRXS(ISC) zhangliang4629@163.com 2015/11/14 9:54:24
 * *******************************************************/
using System.Collections.Generic;

namespace Frxs.Erp.ServiceCenter.ID.SDK
{
    /// <summary>
    ///  HTTP���󷵻ض���
    /// </summary>
    internal class HttpRespBody
    {
        /// <summary>
        /// ���ڱ���http-Headers��Ϣ
        /// </summary>
        private Dictionary<string, string> _headers = new Dictionary<string, string>();

        /// <summary>
        /// ������������
        /// </summary>
        /// <param name="body">���ص�body����</param>
        public HttpRespBody(string body)
        {
            this.Body = body;
        }

        /// <summary>
        /// ���ص�body����
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// ���ص�ͷ��Ϣ
        /// </summary>
        public Dictionary<string, string> Headers
        {
            get
            {
                return this._headers;
            }
        }
    }
}
