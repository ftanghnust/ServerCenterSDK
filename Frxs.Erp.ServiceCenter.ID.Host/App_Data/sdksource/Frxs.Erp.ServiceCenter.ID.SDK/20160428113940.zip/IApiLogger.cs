/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 11/2/2015 8:32:16 PM
 * *******************************************************/
using System;

namespace Frxs.Erp.ServiceCenter.ID.SDK
{
    /// <summary>
    /// ��־���ӿڡ�
    /// </summary>
    public interface IApiLogger {

        /// <summary>
        /// ��¼����������־
        /// </summary>
        /// <param name="message"></param>
        void Error(string message);

        /// <summary>
        /// ��¼����������־
        /// </summary>
        /// <param name="message"></param>
        void Warn(string message);

        /// <summary>
        /// ��¼��Ϣ������־
        /// </summary>
        /// <param name="message"></param>
        void Info(string message);
    }
}
