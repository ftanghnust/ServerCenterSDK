/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 11/3/2015 12:56:17 PM
 * *******************************************************/

namespace Frxs.Erp.ServiceCenter.ID.SDK
{
    /// <summary>
    /// ����ʽ
    /// </summary>
    public enum HttpMethod
    {
        /// <summary>
        /// HTTP-POST
        /// </summary>
        POST,

        /// <summary>
        /// HTTP-GET
        /// </summary>
        GET

    }
}
