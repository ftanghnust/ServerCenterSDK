/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-28 11:39:40
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.ID.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Id.Ids.Get
* ActionType:Frxs.Erp.ServiceCenter.ID.Actions.IdsGetAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionAuthentication]
* AuthorName:
* CacheTime:0
* CanPackageToSDK:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Id.Ids.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.ID.Actions.RequestDto.IdsGetRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.String
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.ID.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpIdIdsGetRequest : RequestBase<Resp.FrxsErpIdIdsGetResp> 
	{
		/// <summary>
		/// 
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public IDTypes Type { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Id.Ids.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Id.Ids.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,this.Type,this.UserId,this.UserName }.ToJson();
		}

		/// <summary>
		/// 
		/// </summary>
		public enum IDTypes
		{
			BuyBack=0,
			BuyOrder=1,
			CheckStock=2,
			CheckStockPlan=3,
			FeeID=4,
			SaleBack=5,
			SaleEdit=6,
			SaleOrder=7,
			SaleSettle=8,
			StockAdj=9,
			BaseInfoID=10,
			ShelfAdjust=11
		}

	}
}