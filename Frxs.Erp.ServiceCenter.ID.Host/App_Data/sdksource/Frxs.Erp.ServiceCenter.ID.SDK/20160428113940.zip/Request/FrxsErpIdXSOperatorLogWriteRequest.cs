/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-28 11:39:40
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.ID.Actions
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Id.XSOperatorLog.Write
* ActionType:Frxs.Erp.ServiceCenter.ID.Actions.XSOperatorLogWrite
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionAuthentication]
* AuthorName:
* CacheTime:0
* CanPackageToSDK:True
* DataSignatureTransmission:True
* Description:Frxs.Erp.Id.XSOperatorLog.Write
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.ID.Actions.XSOperatorLogWrite+XSOperatorLogWriteRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.ID.SDK.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsErpIdXSOperatorLogWriteRequest : RequestBase<Resp.FrxsErpIdXSOperatorLogWriteResp> 
	{
		/// <summary>
		/// 
		/// </summary>
		public SysEnum WID { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public MenuIDEnum MenuID { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string Action { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string Remark { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Id.XSOperatorLog.Write
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Id.XSOperatorLog.Write";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.MenuID,
				this.Action,
				this.Remark,
				this.UserId,
				this.UserName }.ToJson();
		}

		/// <summary>
		/// 
		/// </summary>
		public enum SysEnum
		{
			MS=51,
			WMS=52
		}

		/// <summary>
		/// 
		/// </summary>
		public enum MenuIDEnum
		{
			MS_1=5111,
			MS_2=5112,
			WMS_1=5201,
			WMS_2=5202,
			WMS_3=5203,
			WMS_4=5204,
			WMS_5=5205,
			WMS_6=5206,
			WMS_7=5207,
			WMS_18=5218,
			MS_1A=511101,
			MS_1B=511102,
			MS_1C=511103,
			MS_2A=511201,
			MS_2B=511202,
			MS_2C=511203,
			MS_2E=511204,
			MS_2D=511205,
			MS_2F=511206,
			MS_2H=511207,
			WMS_1A=520110,
			WMS_1B=520112,
			WMS_1C=520113,
			WMS_1D=520114,
			WMS_1E=520115,
			WMS_1F=520116,
			WMS_1G=520117,
			WMS_1H=520118,
			WMS_1Z=520119,
			WMS_2A=520221,
			WMS_2B=520222,
			WMS_2C=520223,
			WMS_2D=520224,
			WMS_2E=520225,
			WMS_2F=520226,
			WMS_2G=520227,
			WMS_2H=520228,
			WMS_2I=520229,
			WMS_3A=520311,
			WMS_3B=520312,
			WMS_3C=520313,
			WMS_3D=520314,
			WMS_3E=520315,
			WMS_3F=520316,
			WMS_3G=520317,
			WMS_4A=520411,
			WMS_4B=520412,
			WMS_4C=520413,
			WMS_5B=520511,
			WMS_5C=520512,
			WMS_5D=520513,
			WMS_5E=520514,
			WMS_6A=520611,
			WMS_6B=520612,
			WMS_7A=520711,
			WMS_7B=520712,
			WMS_7C=520713,
			WMS_7H=520714,
			WMS_7D=520715,
			WMS_7E=520716,
			WMS_7F=520717,
			WMS_18A=521811,
			WMS_18B=521812,
			WMS_18C=521813,
			WMS_18D=521814,
			WMS_18E=521815,
			WMS_18F=521816,
			WMS_18G=521817,
			WMS_18H=521818,
			WMS_18I=521819,
			WMS_18J=521820
		}

	}
}