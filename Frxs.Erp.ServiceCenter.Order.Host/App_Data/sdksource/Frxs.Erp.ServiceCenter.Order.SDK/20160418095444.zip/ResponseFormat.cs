/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 2015/11/10 11:10:52
 * *******************************************************/

namespace Frxs.Erp.ServiceCenter.Order.SDK
{
    /// <summary>
    /// �ӿ����ģʽ
    /// </summary>
    public enum ResponseFormat
    {
        /// <summary>
        /// ���л���XML��ʽ
        /// </summary>
        XML,

        /// <summary>
        /// ���л���JSON��ʽ
        /// </summary>
        JSON
    }
    
}
