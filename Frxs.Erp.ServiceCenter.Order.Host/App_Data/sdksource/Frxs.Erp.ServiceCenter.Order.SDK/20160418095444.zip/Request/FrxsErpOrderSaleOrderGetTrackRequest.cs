/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.SaleOrder.GetTrack
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.SaleOrderGetTrackAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.SaleOrder.GetTrack
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.OrderBaseRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Order.Actions.ResponseDto.Order.SaleOrderTracksGetResponseDto
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// ��ȡ����������Ϣ
	/// </summary>
	public class FrxsErpOrderSaleOrderGetTrackRequest : RequestBase<Resp.FrxsErpOrderSaleOrderGetTrackResp> 
	{
		/// <summary>
		/// ����ID
		/// </summary>
		public string OrderId { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int WarehouseId { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.SaleOrder.GetTrack
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.SaleOrder.GetTrack";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.OrderId,this.WarehouseId,this.UserId,this.UserName }.ToJson();
		}

	}
}