/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.StockAdj.List.Get
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.Stock.StockAdjListGetAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.StockAdj.List.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.Stock.StockAdjListGetAction+StockAdjListGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Order.Model.StockAdj]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// �̵��������(�̿���ӯ��) �б���ѯ
	/// </summary>
	public class FrxsErpOrderStockAdjListGetRequest : RequestBase<Resp.FrxsErpOrderStockAdjListGetResp> 
	{
		/// <summary>
		/// �ֿ�ID ���ݸ�ID���������ĸ����ݿ�
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// ����
		/// </summary>
		public string AdjID { get; set; }
		/// <summary>
		/// ��������(0:�������;1:�������)
		/// </summary>
		public int AdjType { get; set; }
		/// <summary>
		/// ��Ʒ����
		/// </summary>
		public string ProductName { get; set; }
		/// <summary>
		/// ��Ʒ����
		/// </summary>
		public string SKU { get; set; }
		/// <summary>
		/// ����״̬(0:δ�ύ;1:���ύ;2:�ѹ���;3:����) 0>1 1->2 1>0; 1>3; 0 ɾ��ʱ����ɾ��)
		/// </summary>
		public int? Status { get; set; }
		/// <summary>
		/// �ֿ��ӻ���ID
		/// </summary>
		public int? SubWID { get; set; }
		/// <summary>
		/// �������� ��ʼʱ���
		/// </summary>
		public DateTime? AdjDateBegin { get; set; }
		/// <summary>
		/// �������� ��ֹʱ���
		/// </summary>
		public DateTime? AdjDateEnd { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.StockAdj.List.Get
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.StockAdj.List.Get";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.AdjID,
				this.AdjType,
				this.ProductName,
				this.SKU,
				this.Status,
				this.SubWID,
				this.AdjDateBegin,
				this.AdjDateEnd,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}