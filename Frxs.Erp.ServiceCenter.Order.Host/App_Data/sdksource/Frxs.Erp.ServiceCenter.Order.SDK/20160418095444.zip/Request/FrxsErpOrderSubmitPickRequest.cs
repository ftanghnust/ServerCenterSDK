/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.SubmitPick
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.SubmitPickAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.SubmitPick
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.SubmitPickAction+SubmitPickActionRequest
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Boolean
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// �ύ���
	/// </summary>
	public class FrxsErpOrderSubmitPickRequest : RequestBase<Resp.FrxsErpOrderSubmitPickResp> 
	{
		/// <summary>
		/// ���ύ����Ķ�������Ʒ��ϸ(���л�)
		/// </summary>
		public string ProductData { get; set; }
		/// <summary>
		/// �ֿ���
		/// </summary>
		public string WID { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.SubmitPick
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.SubmitPick";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.ProductData,this.WID,this.UserId,this.UserName }.ToJson();
		}

	}
}