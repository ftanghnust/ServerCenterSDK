/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.StockQty.BatStockIn
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.Stock.BatStockInAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.StockQty.BatStockIn
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.Stock.BatStockInDTO
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Boolean
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// ����������ȡ�����Ϣ
	/// </summary>
	public class FrxsErpOrderStockQtyBatStockInRequest : RequestBase<Resp.FrxsErpOrderStockQtyBatStockInResp> 
	{
		/// <summary>
		/// 
		/// </summary>
		public BatStockInModel Data { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.StockQty.BatStockIn
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.StockQty.BatStockIn";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.Data,this.UserId,this.UserName }.ToJson();
		}

		/// <summary>
		/// 
		/// </summary>
		public class BatStockInModel
		{
			/// <summary>
			/// ���������ƷID
			/// </summary>
			public IList<StockFIFOInModel> InPList { get; set; }
			/// <summary>
			/// ���κ�(���κ�)(ID_SERVICE_BATCHNO.ID)
			/// </summary>
			public string BatchNO { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ���
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// �ֿ�����
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// �ֿ��̨ID(Warehouse.WID)
			/// </summary>
			public int SubWID { get; set; }
			/// <summary>
			/// ��̨����
			/// </summary>
			public string SubWName { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int? CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
		}

		/// <summary>
		/// ����ȳ��㷨���
		/// </summary>
		public class StockFIFOInModel
		{
			/// <summary>
			/// ����
			/// </summary>
			public long InID { get; set; }
			/// <summary>
			/// ���κ�(���κ�)(ID_SERVICE_BATCHNO.ID)
			/// </summary>
			public string BatchNO { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ���
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// �ֿ�����
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// �ֿ��̨ID(Warehouse.WID)
			/// </summary>
			public int SubWID { get; set; }
			/// <summary>
			/// ��̨����
			/// </summary>
			public string SubWName { get; set; }
			/// <summary>
			/// ��ƷID(Products.ProductID)
			/// </summary>
			public int ProductID { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string SKU { get; set; }
			/// <summary>
			/// ��Ʒ����
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// ���ԭ��������
			/// </summary>
			public decimal StockQty { get; set; }
			/// <summary>
			/// ��������(0���ɹ����;1:�����˻�;2:��ӯ)
			/// </summary>
			public int BillType { get; set; }
			/// <summary>
			/// ����ID
			/// </summary>
			public string BillID { get; set; }
			/// <summary>
			/// ����ID��ϸID
			/// </summary>
			public string BillDetailID { get; set; }
			/// <summary>
			/// ��浥λ
			/// </summary>
			public string Unit { get; set; }
			/// <summary>
			/// ����浥λ��Ʒ����
			/// </summary>
			public decimal Qty { get; set; }
			/// <summary>
			/// �ѳ����浥λ��Ʒ����
			/// </summary>
			public decimal TotalOutQty { get; set; }
			/// <summary>
			/// �ѳ�����ʶ(0:δ����;1:�ѳ���)
			/// </summary>
			public int Flag { get; set; }
			/// <summary>
			/// ��Ӧ��ID
			/// </summary>
			public int VendorID { get; set; }
			/// <summary>
			/// ��Ӧ�̱��
			/// </summary>
			public string VendorCode { get; set; }
			/// <summary>
			/// ��Ӧ������
			/// </summary>
			public string VendorName { get; set; }
			/// <summary>
			/// ���۸�
			/// </summary>
			public decimal InPrice { get; set; }
			/// <summary>
			/// ���ʱ��
			/// </summary>
			public DateTime StockTime { get; set; }
			/// <summary>
			/// �޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
		}

	}
}