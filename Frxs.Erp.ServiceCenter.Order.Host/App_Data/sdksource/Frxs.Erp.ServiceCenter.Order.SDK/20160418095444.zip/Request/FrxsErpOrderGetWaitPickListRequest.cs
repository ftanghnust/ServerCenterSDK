/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.GetWaitPickList
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.GetWaitPickListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.GetWaitPickList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.GetWaitPickListAction+GetWaitPickListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Order.Actions.GetWaitPickListAction+GetWaitPickListActionResponseDto
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// ����ӿ�-����������б�-��ҳ
	/// </summary>
	public class FrxsErpOrderGetWaitPickListRequest : RequestBase<Resp.FrxsErpOrderGetWaitPickListResp> 
	{
		/// <summary>
		/// �������
		/// </summary>
		public string OrderId { get; set; }
		/// <summary>
		/// ����ID
		/// </summary>
		public string SettleID { get; set; }
		/// <summary>
		/// �ֿ�ID
		/// </summary>
		public string WID { get; set; }
		/// <summary>
		/// �µ�ʱ��
		/// </summary>
		public DateTime? OrderDate { get; set; }
		/// <summary>
		/// ��������(0:�ͻ�;1:�ͷ�����)
		/// </summary>
		public int? OrderType { get; set; }
		/// <summary>
		/// �ֿ���
		/// </summary>
		public string WCode { get; set; }
		/// <summary>
		/// �ֿ�����
		/// </summary>
		public string WName { get; set; }
		/// <summary>
		/// �µ��ŵ���
		/// </summary>
		public int? ShopID { get; set; }
		/// <summary>
		/// �µ��ŵ���ԱID
		/// </summary>
		public int? XSUserID { get; set; }
		/// <summary>
		/// �µ��ŵ�����(0:���˵�;1:ǩԼ��)
		/// </summary>
		public int? ShopType { get; set; }
		/// <summary>
		/// �µ��ŵ����
		/// </summary>
		public string ShopCode { get; set; }
		/// <summary>
		/// �µ��ŵ�����
		/// </summary>
		public string ShopName { get; set; }
		/// <summary>
		/// ����״̬
		/// </summary>
		public int? Status { get; set; }
		/// <summary>
		/// �ŵ��ַ
		/// </summary>
		public string Address { get; set; }
		/// <summary>
		/// �ŵ�ʡID
		/// </summary>
		public int? ProvinceID { get; set; }
		/// <summary>
		/// �ŵ���ID
		/// </summary>
		public int? CityID { get; set; }
		/// <summary>
		/// �ŵ���ID
		/// </summary>
		public int? RegionID { get; set; }
		/// <summary>
		/// �ŵ��ַȫ��
		/// </summary>
		public string FullAddress { get; set; }
		/// <summary>
		/// �ŵ��ջ�������
		/// </summary>
		public string RevLinkMan { get; set; }
		/// <summary>
		/// �ŵ��ջ��˵绰
		/// </summary>
		public string RevTelephone { get; set; }
		/// <summary>
		/// �ŵ�������·
		/// </summary>
		public int? LineID { get; set; }
		/// <summary>
		/// �ŵ�ÿ�ն�����ˮ��
		/// </summary>
		public int? StationNumber { get; set; }
		/// <summary>
		/// ��ע
		/// </summary>
		public string Remark { get; set; }
		/// <summary>
		/// �������
		/// </summary>
		public string ShelfAreaID { get; set; }
		/// <summary>
		/// ҳ����
		/// </summary>
		public int? PageIndex { get; set; }
		/// <summary>
		/// ҳ�ߴ�
		/// </summary>
		public int? PageSize { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.GetWaitPickList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.GetWaitPickList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.OrderId,
				this.SettleID,
				this.WID,
				this.OrderDate,
				this.OrderType,
				this.WCode,
				this.WName,
				this.ShopID,
				this.XSUserID,
				this.ShopType,
				this.ShopCode,
				this.ShopName,
				this.Status,
				this.Address,
				this.ProvinceID,
				this.CityID,
				this.RegionID,
				this.FullAddress,
				this.RevLinkMan,
				this.RevTelephone,
				this.LineID,
				this.StationNumber,
				this.Remark,
				this.ShelfAreaID,
				this.PageIndex,
				this.PageSize,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}