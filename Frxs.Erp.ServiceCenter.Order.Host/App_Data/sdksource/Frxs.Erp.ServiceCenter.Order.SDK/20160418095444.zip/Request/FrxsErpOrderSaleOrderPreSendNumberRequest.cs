/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.SaleOrderPre.SendNumber
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.SaleOrderPreSendNumberAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.SaleOrderPre.SendNumber
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.SaleOrderSendNumberRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Boolean
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// ���ж�������˳��
	/// </summary>
	public class FrxsErpOrderSaleOrderPreSendNumberRequest : RequestBase<Resp.FrxsErpOrderSaleOrderPreSendNumberResp> 
	{
		/// <summary>
		/// �������(SaleOrder.OrderID)
		/// </summary>
		public string OrderID { get; set; }
		/// <summary>
		/// �ֿ�ID(Warehouse.WID)
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// ��·˳��(WarehouseLine.SerialNumber)
		/// </summary>
		public int LineSerialNumber { get; set; }
		/// <summary>
		/// �ŵ�˳��(WarehouseLineShop.SerialNumber)
		/// </summary>
		public int ShopSerialNumber { get; set; }
		/// <summary>
		/// �ֶ�����˳��(�ö�Ϊ1;�õ�Ϊ9999; ����ȷ��ʱĬ��ֵΪ999);
		/// </summary>
		public int SendNumber { get; set; }
		/// <summary>
		/// ��ע
		/// </summary>
		public int? Remark { get; set; }
		/// <summary>
		/// ����޸�ʱ��
		/// </summary>
		public DateTime ModifyTime { get; set; }
		/// <summary>
		/// ����޸��û�ID
		/// </summary>
		public int? ModifyUserID { get; set; }
		/// <summary>
		/// ����޸��û�����
		/// </summary>
		public string ModifyUserName { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int WarehouseId { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.SaleOrderPre.SendNumber
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.SaleOrderPre.SendNumber";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.OrderID,
				this.WID,
				this.LineSerialNumber,
				this.ShopSerialNumber,
				this.SendNumber,
				this.Remark,
				this.ModifyTime,
				this.ModifyUserID,
				this.ModifyUserName,
				this.WarehouseId,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}