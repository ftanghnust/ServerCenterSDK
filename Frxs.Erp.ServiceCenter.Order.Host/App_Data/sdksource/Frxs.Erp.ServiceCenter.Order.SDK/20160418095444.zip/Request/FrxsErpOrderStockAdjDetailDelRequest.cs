/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.StockAdjDetail.Del
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.Stock.StockAdjDetailDelAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.StockAdjDetail.Del
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.Stock.StockAdjDetailDelAction+StockAdjDetailDelActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Int32
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// �̵������ϸ�� ɾ������
	/// </summary>
	public class FrxsErpOrderStockAdjDetailDelRequest : RequestBase<Resp.FrxsErpOrderStockAdjDetailDelResp> 
	{
		/// <summary>
		/// Ҫɾ����ID����
		/// </summary>
		public List<string> IdList { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int WarehouseId { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.StockAdjDetail.Del
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.StockAdjDetail.Del";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.IdList,this.WarehouseId,this.UserId,this.UserName }.ToJson();
		}

	}
}