/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.vSaleOrder.Query
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.Order.�ֿⶩ��.vSaleOrderQueryAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.vSaleOrder.Query
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.SaleOrderPreBaseRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Order.Actions.ResponseDto.SaleOrderPreQueryResponseDto
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// ��ѯ���ж����Լ���ϸ������Ϣ������saleOrderPre��saleOrder��
	/// </summary>
	public class FrxsErpOrdervSaleOrderQueryRequest : RequestBase<Resp.FrxsErpOrdervSaleOrderQueryResp> 
	{
		/// <summary>
		/// �������
		/// </summary>
		public string OrderId { get; set; }
		/// <summary>
		/// ����ʱ��-��ʼ��Χ
		/// </summary>
		public DateTime? OrderDateBegin { get; set; }
		/// <summary>
		/// ����ʱ��-������Χ
		/// </summary>
		public DateTime? OrderDateEnd { get; set; }
		/// <summary>
		/// ���㵥���
		/// </summary>
		public string SettleID { get; set; }
		/// <summary>
		/// ����״̬
		/// </summary>
		public int? Status { get; set; }
		/// <summary>
		/// �ŵ�ID
		/// </summary>
		public int? ShopId { get; set; }
		/// <summary>
		/// �ֿ�ID
		/// </summary>
		public int? WID { get; set; }
		/// <summary>
		/// �ŵ�����
		/// </summary>
		public string ShopName { get; set; }
		/// <summary>
		/// ����·��
		/// </summary>
		public int? LineID { get; set; }
		/// <summary>
		/// ����·������
		/// </summary>
		public string LineName { get; set; }
		/// <summary>
		/// �ŵ�Code
		/// </summary>
		public string ShopCode { get; set; }
		/// <summary>
		/// �ŵ�����
		/// </summary>
		public int? ShopType { get; set; }
		/// <summary>
		/// ȷ��ʱ�俪ʼ
		/// </summary>
		public DateTime? ConfDateBegin { get; set; }
		/// <summary>
		/// ȷ��ʱ�����
		/// </summary>
		public DateTime? ConfDateEnd { get; set; }
		/// <summary>
		/// ����ʱ�俪ʼ
		/// </summary>
		public DateTime? ShippingBeginDateBegin { get; set; }
		/// <summary>
		/// ����ʱ�����
		/// </summary>
		public DateTime? ShippingBeginDateEnd { get; set; }
		/// <summary>
		/// Ԥ���ʹ�ʱ�俪ʼ
		/// </summary>
		public DateTime? SendDateBegin { get; set; }
		/// <summary>
		/// Ԥ���ʹ�ʱ�����
		/// </summary>
		public DateTime? SendDateEnd { get; set; }
		/// <summary>
		/// ҳ��
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// ҳ����
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// �����ֶ�
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// �Ӳֿ�ID
		/// </summary>
		public int? SubID { get; set; }
		/// <summary>
		/// �Ƿ��ӡ
		/// </summary>
		public int? IsPrinted { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int WarehouseId { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.vSaleOrder.Query
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.vSaleOrder.Query";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.OrderId,
				this.OrderDateBegin,
				this.OrderDateEnd,
				this.SettleID,
				this.Status,
				this.ShopId,
				this.WID,
				this.ShopName,
				this.LineID,
				this.LineName,
				this.ShopCode,
				this.ShopType,
				this.ConfDateBegin,
				this.ConfDateEnd,
				this.ShippingBeginDateBegin,
				this.ShippingBeginDateEnd,
				this.SendDateBegin,
				this.SendDateEnd,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.SubID,
				this.IsPrinted,
				this.WarehouseId,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}