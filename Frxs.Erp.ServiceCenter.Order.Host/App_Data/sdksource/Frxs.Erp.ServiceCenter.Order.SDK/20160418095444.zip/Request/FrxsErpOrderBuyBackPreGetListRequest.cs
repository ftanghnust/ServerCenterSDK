/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.BuyBackPre.GetList
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.BuyBackPreGetListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.BuyBackPre.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.BuyBackPreGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Order.Model.BuyBackPre]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// �ɹ��˻���(������)��ҳ��ѯ
	/// </summary>
	public class FrxsErpOrderBuyBackPreGetListRequest : RequestBase<Resp.FrxsErpOrderBuyBackPreGetListResp> 
	{
		/// <summary>
		/// �ֿ�ID
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// �ֿ��ӻ������
		/// </summary>
		public int? SubWID { get; set; }
		/// <summary>
		/// �ɹ��˻������
		/// </summary>
		public string BackID { get; set; }
		/// <summary>
		/// ��Ӧ��Code���߹�Ӧ������
		/// </summary>
		public string VendorCodeOrName { get; set; }
		/// <summary>
		/// ��Ʒ���
		/// </summary>
		public string SKU { get; set; }
		/// <summary>
		/// ������Ʒ����(Product.ProductName)
		/// </summary>
		public string ProductName { get; set; }
		/// <summary>
		/// ״̬(0:δ�ύ;1:���ύ;2:�ѹ���;3:�ѽ���)
		/// </summary>
		public int? Status { get; set; }
		/// <summary>
		/// �˻�ʱ�� ��ʼ
		/// </summary>
		public string OrderDateBegin { get; set; }
		/// <summary>
		/// �˻�ʱ�� ����
		/// </summary>
		public string OrderDateEnd { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.BuyBackPre.GetList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.BuyBackPre.GetList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.SubWID,
				this.BackID,
				this.VendorCodeOrName,
				this.SKU,
				this.ProductName,
				this.Status,
				this.OrderDateBegin,
				this.OrderDateEnd,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}