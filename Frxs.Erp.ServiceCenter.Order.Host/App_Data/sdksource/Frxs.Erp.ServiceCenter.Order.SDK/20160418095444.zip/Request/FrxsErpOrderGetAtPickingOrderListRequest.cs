/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.GetAtPickingOrderList
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.GetAtPickingOrderListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.GetAtPickingOrderList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.GetAtPickingOrderListAction+GetAtPickingOrderListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Order.Actions.GetAtPickingOrderListAction+GetAtPickingOrderListActionResponseDto
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// ����ӿ�-���ڼ�������б�-��ҳ
	/// </summary>
	public class FrxsErpOrderGetAtPickingOrderListRequest : RequestBase<Resp.FrxsErpOrderGetAtPickingOrderListResp> 
	{
		/// <summary>
		/// �������
		/// </summary>
		public string OrderId { get; set; }
		/// <summary>
		/// �ŵ���(����)
		/// </summary>
		public int? ShopID { get; set; }
		/// <summary>
		/// �ŵ����(��ʽ)
		/// </summary>
		public string ShopCode { get; set; }
		/// <summary>
		/// �ŵ�����
		/// </summary>
		public string ShopName { get; set; }
		/// <summary>
		/// �ŵ�����(0:���˵ꣻ1��ǩԼ��)
		/// </summary>
		public int? ShopType { get; set; }
		/// <summary>
		/// �������
		/// </summary>
		public int? ShelfAreaID { get; set; }
		/// <summary>
		/// �µ�ʱ��
		/// </summary>
		public DateTime? OrderDate { get; set; }
		/// <summary>
		/// ��������
		/// </summary>
		public int? OrderType { get; set; }
		/// <summary>
		/// �ֿ���
		/// </summary>
		public string WID { get; set; }
		/// <summary>
		/// �ֿ����
		/// </summary>
		public string WCode { get; set; }
		/// <summary>
		/// �ֿ�����
		/// </summary>
		public string WName { get; set; }
		/// <summary>
		/// �ֿ��̨����
		/// </summary>
		public string SubWCode { get; set; }
		/// <summary>
		/// �ֿ��̨����
		/// </summary>
		public string SubWName { get; set; }
		/// <summary>
		/// �ŵ�ʡ��ID
		/// </summary>
		public int? ProvinceID { get; set; }
		/// <summary>
		/// �ŵ���ID
		/// </summary>
		public int? CityID { get; set; }
		/// <summary>
		/// �ŵ���ID
		/// </summary>
		public int? RegionID { get; set; }
		/// <summary>
		/// �ŵ�ʡ������
		/// </summary>
		public string ProvinceName { get; set; }
		/// <summary>
		/// �ŵ�������
		/// </summary>
		public string CityName { get; set; }
		/// <summary>
		/// �ŵ�������
		/// </summary>
		public string RegionName { get; set; }
		/// <summary>
		/// �ŵ�����·�߱��
		/// </summary>
		public int? LineID { get; set; }
		/// <summary>
		/// ҳ����
		/// </summary>
		public int? PageIndex { get; set; }
		/// <summary>
		/// ҳ�ߴ�
		/// </summary>
		public int? PageSize { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.GetAtPickingOrderList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.GetAtPickingOrderList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.OrderId,
				this.ShopID,
				this.ShopCode,
				this.ShopName,
				this.ShopType,
				this.ShelfAreaID,
				this.OrderDate,
				this.OrderType,
				this.WID,
				this.WCode,
				this.WName,
				this.SubWCode,
				this.SubWName,
				this.ProvinceID,
				this.CityID,
				this.RegionID,
				this.ProvinceName,
				this.CityName,
				this.RegionName,
				this.LineID,
				this.PageIndex,
				this.PageSize,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}