/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.SaleSettle.GetList
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.SaleSettleGetListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.SaleSettle.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.SaleSettleGetListAction+SaleSettleGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Order.Model.SaleSettle]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// ���۽��㵥���б���ѯ
	/// </summary>
	public class FrxsErpOrderSaleSettleGetListRequest : RequestBase<Resp.FrxsErpOrderSaleSettleGetListResp> 
	{
		/// <summary>
		/// �ֿ���
		/// </summary>
		public int WID { get; set; }
		/// <summary>
		/// �ŵ���
		/// </summary>
		public int? ShopID { get; set; }
		/// <summary>
		/// ״̬
		/// </summary>
		public int? Status { get; set; }
		/// <summary>
		/// ���㵥��
		/// </summary>
		public string SettleID { get; set; }
		/// <summary>
		/// ���㿪ʼʱ��
		/// </summary>
		public DateTime? StartTime { get; set; }
		/// <summary>
		/// �������ʱ��
		/// </summary>
		public DateTime? EndTime { get; set; }
		/// <summary>
		/// �ŵ��� addluojing
		/// </summary>
		public string ShopCode { get; set; }
		/// <summary>
		/// �ŵ����� addluojing
		/// </summary>
		public string ShopName { get; set; }
		/// <summary>
		/// ���㷽ʽ addluojing
		/// </summary>
		public string SettleType { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.SaleSettle.GetList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.SaleSettle.GetList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.WID,
				this.ShopID,
				this.Status,
				this.SettleID,
				this.StartTime,
				this.EndTime,
				this.ShopCode,
				this.ShopName,
				this.SettleType,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}