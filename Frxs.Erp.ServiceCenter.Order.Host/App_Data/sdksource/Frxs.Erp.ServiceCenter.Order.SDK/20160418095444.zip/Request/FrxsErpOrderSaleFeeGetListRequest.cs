/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.SaleFee.GetList
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.SaleFeeGetListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.SaleFee.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.SaleFeeGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Order.Model.SaleFee]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Request
{
	/// <summary>
	/// �ŵ���� ��ҳ��ѯ
	/// </summary>
	public class FrxsErpOrderSaleFeeGetListRequest : RequestBase<Resp.FrxsErpOrderSaleFeeGetListResp> 
	{
		/// <summary>
		/// ����ID(SaleFee.FeeID)
		/// </summary>
		public string FeeID { get; set; }
		/// <summary>
		/// �ֿ�ID(WarehouseID)
		/// </summary>
		public int? WID { get; set; }
		/// <summary>
		/// �ֿ�ID ��Ӧ�ŵ���ñ��е�WID
		/// </summary>
		public int? WarehouseID { get; set; }
		/// <summary>
		/// �ֿ���(Warehouse.WCode)
		/// </summary>
		public string WCode { get; set; }
		/// <summary>
		/// �ֿ�����(Warehouse.WarehouseName)
		/// </summary>
		public string WName { get; set; }
		/// <summary>
		/// ״̬(0:δ�ύ;1:���ύ;2:�ѹ���;3:�ѽ���)
		/// </summary>
		public int? Status { get; set; }
		/// <summary>
		/// ���ý��(С��0���������˻�;����0������������)(=sum(SaleFeeDetail.FeeAmt)
		/// </summary>
		public double? TotalFeeAmt { get; set; }
		/// <summary>
		/// ȷ����Ա
		/// </summary>
		public string ConfUserName { get; set; }
		/// <summary>
		/// ��������
		/// </summary>
		public DateTime? FeeDate { get; set; }
		/// <summary>
		/// �ŵ����
		/// </summary>
		public string ShopCode { get; set; }
		/// <summary>
		/// �ŵ�����
		/// </summary>
		public string ShopName { get; set; }
		/// <summary>
		/// �������ڣ���ʼ��
		/// </summary>
		public DateTime? StartFeeDate { get; set; }
		/// <summary>
		/// �������ڣ�������
		/// </summary>
		public DateTime? EndFeeDate { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageIndex { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public int PageSize { get; set; }
		/// <summary>
		/// 
		/// </summary>
		public string SortBy { get; set; }
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Erp.Order.SaleFee.GetList
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Erp.Order.SaleFee.GetList";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.FeeID,
				this.WID,
				this.WarehouseID,
				this.WCode,
				this.WName,
				this.Status,
				this.TotalFeeAmt,
				this.ConfUserName,
				this.FeeDate,
				this.ShopCode,
				this.ShopName,
				this.StartFeeDate,
				this.EndFeeDate,
				this.PageIndex,
				this.PageSize,
				this.SortBy,
				this.UserId,
				this.UserName }.ToJson();
		}

	}
}