/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.SaleBackPre.GetList
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.SaleBackPreGetListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.SaleBackPre.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.SaleBackPreGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Order.Model.SaleBackPre]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Resp
{
	/// <summary>
	/// �����˻���(������)��ҳ��ѯ
	/// </summary>
	public class FrxsErpOrderSaleBackPreGetListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpOrderSaleBackPreGetListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpOrderSaleBackPreGetListRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<SaleBackPre> ItemList { get; set; }
		}

		/// <summary>
		/// SaleBackPreʵ����
		/// </summary>
		public class SaleBackPre
		{
			/// <summary>
			/// �˻������
			/// </summary>
			public string BackID { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ���(Warehouse.WCode)
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// �ֿ�����(Warehouse.WName)
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// �ֿ��̨ID
			/// </summary>
			public int SubWID { get; set; }
			/// <summary>
			/// �ֿ��̨���(Warehouse.WCode)
			/// </summary>
			public string SubWCode { get; set; }
			/// <summary>
			/// �ֿ��̨����(Warehouse.WName)
			/// </summary>
			public string SubWName { get; set; }
			/// <summary>
			/// �˻�����(��ʽ:yyyy-MM-dd)
			/// </summary>
			public DateTime BackDate { get; set; }
			/// <summary>
			/// ��ʢ�û�ID(Ԥ��)
			/// </summary>
			public long XSUserID { get; set; }
			/// <summary>
			/// �µ��ŵ�ID
			/// </summary>
			public int ShopID { get; set; }
			/// <summary>
			/// �µ��ŵ���
			/// </summary>
			public string ShopCode { get; set; }
			/// <summary>
			/// �µ��ŵ�����
			/// </summary>
			public string ShopName { get; set; }
			/// <summary>
			/// ״̬(0:δ�ύ;1:��ȷ��;2:�ѹ���;3:�ѽ���)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// �˻����(SaleBackDetails.BackAmt)
			/// </summary>
			public decimal TotalBackAmt { get; set; }
			/// <summary>
			/// ����(SaleBackDetails.SubPoint)
			/// </summary>
			public decimal TotalBasePoint { get; set; }
			/// <summary>
			/// ������
			/// </summary>
			public decimal TotalBackQty { get; set; }
			/// <summary>
			/// �ŵ�ϼ������sum(SaleBackDettail.SubAddAmt)
			/// </summary>
			public decimal? TotalAddAmt { get; set; }
			/// <summary>
			/// ��������/Ӧ�˽�=TotalBackAmtt+TotalAddAmt)
			/// </summary>
			public decimal PayAmount { get; set; }
			/// <summary>
			/// �ύʱ��
			/// </summary>
			public DateTime? ConfTime { get; set; }
			/// <summary>
			/// �ύ�û�ID
			/// </summary>
			public int ConfUserID { get; set; }
			/// <summary>
			/// �ύ�û�����
			/// </summary>
			public string ConfUserName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime? PostingTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int PostingUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string PostingUserName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime? SettleTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int SettleUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string SettleUserName { get; set; }
			/// <summary>
			/// ����ID(SaleSettle.SettleID)
			/// </summary>
			public int SettleID { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// ״̬
			/// </summary>
			public string StatusStr { get; set; }
		}

	}
}