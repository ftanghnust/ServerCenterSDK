/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.SaleOrder.GetTrack
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.SaleOrderGetTrackAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.SaleOrder.GetTrack
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.OrderBaseRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Order.Actions.ResponseDto.Order.SaleOrderTracksGetResponseDto
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Resp
{
	/// <summary>
	/// ��ȡ����������Ϣ
	/// </summary>
	public class FrxsErpOrderSaleOrderGetTrackResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpOrderSaleOrderGetTrackRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpOrderSaleOrderGetTrackRespData
		{
			/// <summary>
			/// ����������Ϣ�б�
			/// </summary>
			public IList<OrderTrackGetResponseDto> Tracks { get; set; }
		}

		/// <summary>
		/// 
		/// </summary>
		public class OrderTrackGetResponseDto
		{
			/// <summary>
			/// ���(�ֿ�ID+GUID)
			/// </summary>
			public string ID { get; set; }
			/// <summary>
			/// �������
			/// </summary>
			public string OrderID { get; set; }
			/// <summary>
			/// �ֿ�ID
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ���û����Ƿ���ʾ(0:����ʾ;1:��ʾ)
			/// </summary>
			public int? IsDisplayUser { get; set; }
			/// <summary>
			/// ״̬���(����Order.OrderStatus)
			/// </summary>
			public int? OrderStatus { get; set; }
			/// <summary>
			/// ״̬�������(����Order.OrderStatus)
			/// </summary>
			public string OrderStatusName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int? CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
		}

	}
}