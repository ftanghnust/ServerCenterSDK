/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.SaleFee.GetList
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.SaleFeeGetListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.SaleFee.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.SaleFeeGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Order.Model.SaleFee]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Resp
{
	/// <summary>
	/// �ŵ���� ��ҳ��ѯ
	/// </summary>
	public class FrxsErpOrderSaleFeeGetListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpOrderSaleFeeGetListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpOrderSaleFeeGetListRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<SaleFee> ItemList { get; set; }
		}

		/// <summary>
		/// SaleFeeʵ����
		/// </summary>
		public class SaleFee
		{
			/// <summary>
			/// ����ID(SaleFee.FeeID)
			/// </summary>
			public string FeeID { get; set; }
			/// <summary>
			/// �ֿ�ID(WarehouseID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ���(Warehouse.WCode)
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// �ֿ�����(Warehouse.WarehouseName)
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// �ֿ��ӻ���ID
			/// </summary>
			public int SubWID { get; set; }
			/// <summary>
			/// �ֿ��ӻ������(Warehouse.WCode)
			/// </summary>
			public string SubWCode { get; set; }
			/// <summary>
			/// �ֿ��ӻ�������(Warehouse.WName)
			/// </summary>
			public string SubWName { get; set; }
			/// <summary>
			/// ״̬(0:¼��;1:ȷ��;2:����;3:����)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// ���ý��(С��0���������˻�;����0������������)(=sum(SaleFeeDetail.FeeAmt)
			/// </summary>
			public double TotalFeeAmt { get; set; }
			/// <summary>
			/// �ύʱ��
			/// </summary>
			public DateTime ConfTime { get; set; }
			/// <summary>
			/// �ύ�û�ID
			/// </summary>
			public int ConfUserID { get; set; }
			/// <summary>
			/// �ύ�û�����
			/// </summary>
			public string ConfUserName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime PostingTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int PostingUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string PostingUserName { get; set; }
			/// <summary>
			/// �������ʱ��
			/// </summary>
			public DateTime SettleTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int SettleUserID { get; set; }
			/// <summary>
			/// �����û�
			/// </summary>
			public string SettleUserName { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public DateTime FeeDate { get; set; }
			/// <summary>
			/// ״̬(0:¼��;1:ȷ��;2:����;3:����)
			/// </summary>
			public string StatusToStr { get; set; }
		}

	}
}