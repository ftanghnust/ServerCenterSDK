/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.ServiceCenter.Api.Core
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:API.ServerTime.Get
* ActionResultCacheAttribute:
* ActionType:Frxs.ServiceCenter.Api.Core.Actions.ServerTimeGetActionV11
* AllowAnonymous:True
* AuthorName:
* CanPackageToSDK:True
* Description:API.ServerTime.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.ServiceCenter.Api.Core.NullRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.String
* Version:1.1
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Resp
{
	/// <summary>
	/// 
	/// </summary>
	public class APIServerTimeGetResp : ResponseBase 
	{
		/// <summary>
		///  
		/// <summary>
		public string Data { get; set; }

	}
}