/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.StockQtyList.Query
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.QueryStockQtyListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.StockQtyList.Query
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.StockOQtyQueryDTO
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Order.Actions.QueryStockOQtyResponseDTO
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Resp
{
	/// <summary>
	/// ����������ȡ�����Ϣ
	/// </summary>
	public class FrxsErpOrderStockQtyListQueryResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpOrderStockQtyListQueryRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpOrderStockQtyListQueryRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public IDictionary`2 WStockQtyDicList { get; set; }
		}

		/// <summary>
		/// 
		/// </summary>
		public class IDictionary`2
		{
			/// <summary>
			/// 
			/// </summary>
			public IList<StockOQtyModel> Item { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public ICollection<Int32> Keys { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public ICollection<IList`1> Values { get; set; }
		}

		/// <summary>
		/// ����ѯ���
		/// </summary>
		public class StockOQtyModel
		{
			/// <summary>
			/// ��ƷID
			/// </summary>
			public int PID { get; set; }
			/// <summary>
			/// �����
			/// </summary>
			public decimal StockQty { get; set; }
		}

		/// <summary>
		/// 
		/// </summary>
		public class IList`1
		{
			/// <summary>
			/// 
			/// </summary>
			public StockOQtyModel Item { get; set; }
		}

	}
}