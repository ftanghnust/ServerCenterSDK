/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.StartPickUpdate
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.PickingStartPickAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.StartPickUpdate
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.PickingStartPickAction+PickingStartPickActionRequestDto
* RequiredUserIdAndUserName:True
* RequireHttps:False
* ResponseDtoType:Frxs.Erp.ServiceCenter.Order.Actions.PickingStartPickAction+PickingStartPickActionResponseDto
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Resp
{
	/// <summary>
	/// ���������ر�����
	/// </summary>
	public class FrxsErpOrderStartPickUpdateResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpOrderStartPickUpdateRespData Data { get; set; }

		/// <summary>
		/// �������
		/// </summary>
		public class FrxsErpOrderStartPickUpdateRespData
		{
			/// <summary>
			/// �ŵ���
			/// </summary>
			public int ShopID { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public DateTime ConfDate { get; set; }
			/// <summary>
			/// ��·���
			/// </summary>
			public int LineID { get; set; }
		}

	}
}