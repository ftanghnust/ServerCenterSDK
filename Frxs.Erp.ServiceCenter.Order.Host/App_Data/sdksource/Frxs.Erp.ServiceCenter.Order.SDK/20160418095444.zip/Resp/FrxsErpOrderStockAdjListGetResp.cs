/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.StockAdj.List.Get
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.Stock.StockAdjListGetAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.StockAdj.List.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.Stock.StockAdjListGetAction+StockAdjListGetActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Order.Model.StockAdj]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Resp
{
	/// <summary>
	/// �̵��������(�̿���ӯ��) �б���ѯ
	/// </summary>
	public class FrxsErpOrderStockAdjListGetResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpOrderStockAdjListGetRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpOrderStockAdjListGetRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<StockAdj> ItemList { get; set; }
		}

		/// <summary>
		/// StockAdjʵ����
		/// </summary>
		public class StockAdj
		{
			/// <summary>
			/// ����ID(WID+ ID����)
			/// </summary>
			public string AdjID { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public DateTime AdjDate { get; set; }
			/// <summary>
			/// �̵�ƻ�ID
			/// </summary>
			public string PlanID { get; set; }
			/// <summary>
			/// �ֿ�ID(WarehouseID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ���(Warehouse.WCode)
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// �ֿ�����(Warehouse.WarehouseName)
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// �ֿ��ӻ���ID(WarehouseID)
			/// </summary>
			public int SubWID { get; set; }
			/// <summary>
			/// �ֿ��ӻ������(Warehouse.WCode)
			/// </summary>
			public string SubWCode { get; set; }
			/// <summary>
			/// �ֿ��̨����(Warehouse.WarehouseName)
			/// </summary>
			public string SubWName { get; set; }
			/// <summary>
			/// ״̬(0:δ�ύ;1:���ύ;2:�ѹ���;3:����) 0>1 1->2 1>0; 1>3; 0 ɾ��ʱ����ɾ��;
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// ��������(0:�������;1:�������)
			/// </summary>
			public int AdjType { get; set; }
			/// <summary>
			/// �ύʱ��
			/// </summary>
			public DateTime? ConfTime { get; set; }
			/// <summary>
			/// �ύ�û�ID
			/// </summary>
			public int? ConfUserID { get; set; }
			/// <summary>
			/// �ύ�û�����
			/// </summary>
			public string ConfUserName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime? PostingTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int? PostingUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string PostingUserName { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int? ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
		}

	}
}