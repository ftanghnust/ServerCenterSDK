/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-04-18 09:54:44
* *********************************************************
* Assembly:Frxs.Erp.ServiceCenter.Order.Actions
* *********************************************************
* ActionAuthenticationAttributes:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionAuthenticationBaseAttribute]
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.ActionFilterBaseAttribute]
* ActionName:Frxs.Erp.Order.BuyOrderPre.GetList
* ActionResultCacheAttribute:
* ActionType:Frxs.Erp.ServiceCenter.Order.Actions.BuyOrderPreGetListAction
* AllowAnonymous:False
* AuthorName:
* CanPackageToSDK:True
* Description:Frxs.Erp.Order.BuyOrderPre.GetList
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.Erp.ServiceCenter.Order.Actions.RequestDto.BuyOrderPreGetListActionRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:Frxs.ServiceCenter.Api.Core.ActionResultPagerData`1[Frxs.Erp.ServiceCenter.Order.Model.BuyOrderPre]
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.Erp.ServiceCenter.Order.SDK.Resp
{
	/// <summary>
	/// �ɹ��ջ���(������)��ҳ��ѯ
	/// </summary>
	public class FrxsErpOrderBuyOrderPreGetListResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public FrxsErpOrderBuyOrderPreGetListRespData Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsErpOrderBuyOrderPreGetListRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int TotalRecords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public List<BuyOrderPre> ItemList { get; set; }
		}

		/// <summary>
		/// BuyOrderPreʵ����
		/// </summary>
		public class BuyOrderPre
		{
			/// <summary>
			/// �ɹ������
			/// </summary>
			public string BuyID { get; set; }
			/// <summary>
			/// �ֿ�ID(Warehouse.WID)
			/// </summary>
			public int WID { get; set; }
			/// <summary>
			/// �ֿ��̨
			/// </summary>
			public int SubWID { get; set; }
			/// <summary>
			/// Ԥ���������(Ԥ��)
			/// </summary>
			public string PreBuyID { get; set; }
			/// <summary>
			/// �ɹ����ʱ��(OrderStatus=1;��ʽ:yyyy-MM-dd HH:mm:ss)
			/// </summary>
			public DateTime OrderDate { get; set; }
			/// <summary>
			/// �ֿ���(Warehouse.WCode)
			/// </summary>
			public string WCode { get; set; }
			/// <summary>
			/// �ֿ�����(Warehouse.WName)
			/// </summary>
			public string WName { get; set; }
			/// <summary>
			/// �ֿ��ӻ������(Warehouse.WCode)
			/// </summary>
			public string SubWCode { get; set; }
			/// <summary>
			/// �ֿ��ӻ�������(Warehouse.WName)
			/// </summary>
			public string SubWName { get; set; }
			/// <summary>
			/// �ɹ�ԱID(WarehouseEmp.EmpID and UserType=4)
			/// </summary>
			public int BuyEmpID { get; set; }
			/// <summary>
			/// �ɹ�Ա����(WarehouseEmp.EmpName and UserType=4)
			/// </summary>
			public string BuyEmpName { get; set; }
			/// <summary>
			/// ��Ӧ�̷���ID
			/// </summary>
			public int VendorID { get; set; }
			/// <summary>
			/// ��Ӧ�̱��
			/// </summary>
			public string VendorCode { get; set; }
			/// <summary>
			/// ��Ӧ������
			/// </summary>
			public string VendorName { get; set; }
			/// <summary>
			/// ״̬(0:δ�ύ;1:���ύ;2:�ѹ���;3:�ѽ���)
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// �ɹ��ܽ��(BuyOrderDetails.SubBuyAmt)
			/// </summary>
			public double TotalOrderAmt { get; set; }
			/// <summary>
			/// �ύʱ��
			/// </summary>
			public DateTime? ConfTime { get; set; }
			/// <summary>
			/// �ύ�û�ID
			/// </summary>
			public int ConfUserID { get; set; }
			/// <summary>
			/// �ύ�û�����
			/// </summary>
			public string ConfUserName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime? PostingTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int PostingUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string PostingUserName { get; set; }
			/// <summary>
			/// ����ʱ��
			/// </summary>
			public DateTime? SettleTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int SettleUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string SettleUserName { get; set; }
			/// <summary>
			/// ����ID(BuySettle.SettleID)
			/// </summary>
			public string SettleID { get; set; }
			/// <summary>
			/// ��ע
			/// </summary>
			public string Remark { get; set; }
			/// <summary>
			/// ��������
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// �����û�ID
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// �����û�����
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// ����޸�ʱ��
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// ����޸��û�ID
			/// </summary>
			public int ModifyUserID { get; set; }
			/// <summary>
			/// ����޸��û�����
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// ״̬
			/// </summary>
			public string StatusStr { get; set; }
			/// <summary>
			/// �ֿ�����
			/// </summary>
			public string WNameStr { get; set; }
		}

	}
}