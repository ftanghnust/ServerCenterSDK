/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 10:15:11
* *********************************************************
* Assembly:Frxs.ServiceCenter.DataSync.Message.ApiHost.DataBase
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Test.V20.Test
* ActionType:Frxs.ServiceCenter.DataSync.Message.ApiHost.DataBase.Actions.TestAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Test.V20.Test
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.ServiceCenter.Api.Core.NullRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.ServiceCenter.DataSync.Message.ApiHost.DataBase.Models.Product]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.ServiceCenter.Api.SDK.V20.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsTestV20TestRequest : RequestBase<Resp.FrxsTestV20TestResp> 
	{
		/// <summary>
		/// ���ýӿ����ƣ�Frxs.Test.V20.Test
		/// </summary>
		/// <returns></returns>
		public override string GetApiName()
		{
			return "Frxs.Test.V20.Test";
		}
		/// <summary>
		/// �������json��
		/// <returns></returns>
		public override string GetRequestJsonData()
		{
			return new { this.UserId,this.UserName }.ToJson();
		}

	}
}