/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 2015/11/10 11:10:52
 * *******************************************************/

namespace Frxs.ServiceCenter.Api.SDK.V20
{
    /// <summary>
    /// �ӿ����ģʽ
    /// </summary>
    public enum ResponseFormat
    {
        /// <summary>
        /// ���л���XML��ʽ
        /// </summary>
        XML,

        /// <summary>
        /// ���л���JSON��ʽ
        /// </summary>
        JSON
    }
    
}
