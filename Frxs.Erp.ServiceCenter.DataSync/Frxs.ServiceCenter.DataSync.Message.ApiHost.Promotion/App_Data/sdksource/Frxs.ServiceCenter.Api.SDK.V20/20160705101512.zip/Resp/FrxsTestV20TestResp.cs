/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 10:15:11
* *********************************************************
* Assembly:Frxs.ServiceCenter.DataSync.Message.ApiHost.DataBase
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:Frxs.Test.V20.Test
* ActionType:Frxs.ServiceCenter.DataSync.Message.ApiHost.DataBase.Actions.TestAction
* AllowAnonymous:False
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:Frxs.Test.V20.Test
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.ServiceCenter.Api.Core.NullRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.Collections.Generic.List`1[Frxs.ServiceCenter.DataSync.Message.ApiHost.DataBase.Models.Product]
* Route:
* UnloadCacheKeys:
* Version:0.0
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.ServiceCenter.Api.SDK.V20.Resp
{
	/// <summary>
	/// 
	/// </summary>
	public class FrxsTestV20TestResp : ResponseBase 
	{
		/// <summary>
		///   
		/// <summary>
		public List<FrxsTestV20TestRespData> Data { get; set; }

		/// <summary>
		/// 
		/// </summary>
		public class FrxsTestV20TestRespData
		{
			/// <summary>
			/// 
			/// </summary>
			public int ProductId { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string SKU { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ProductName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ProductName2 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int BaseProductId { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? ImageProductId { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string Mnemonic { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string Keywords { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int IsDeleted { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int Status { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string TXTKID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string MutAttributes { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string MutValues { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string SaleBackFlag { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? BackDays { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal Volume { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public decimal Weight { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public DateTime CreateTime { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int CreateUserID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string CreateUserName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public DateTime ModifyTime { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? ModifyUserID { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string ModifyUserName { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public int? SyncFale { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string SyncSM { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string VExt1 { get; set; }
			/// <summary>
			/// 
			/// </summary>
			public string VExt2 { get; set; }
		}

	}
}