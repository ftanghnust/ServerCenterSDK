/*********************************************************
* FRXS(ISC) System Auto-Generation At 2016-07-05 10:15:11
* *********************************************************
* Assembly:Frxs.ServiceCenter.Api.Core
* *********************************************************
* ActionFilters:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IActionFilter]
* ActionName:API.ServerTime.Get
* ActionType:Frxs.ServiceCenter.Api.Core.Actions.ServerTimeGetActionV11
* AllowAnonymous:True
* Authentications:System.Collections.Generic.List`1[Frxs.ServiceCenter.Api.Core.IAuthentication]
* AuthorName:
* Cache:Frxs.ServiceCenter.Api.Core.ActionResultCacheAttribute
* CanPackageToSdk:True
* DataSignatureTransmission:True
* Description:API.ServerTime.Get
* EnableAjaxRequest:False
* EnableRecordApiLog:True
* GroupName:�����ӿ�
* HttpMethod:POST, GET
* IsObsolete:False
* RequestDtoType:Frxs.ServiceCenter.Api.Core.NullRequestDto
* RequiredUserIdAndUserName:False
* RequireHttps:False
* ResponseDtoType:System.String
* Route:Frxs.ServiceCenter.Api.Core.RouteAttribute
* UnloadCacheKeys:
* Version:1.1
* *******************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Frxs.ServiceCenter.Api.SDK.V20.Resp
{
	/// <summary>
	/// 
	/// </summary>
	public class APIServerTimeGetResp : ResponseBase 
	{
		/// <summary>
		///  
		/// <summary>
		public string Data { get; set; }

	}
}