/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 11/3/2015 8:29:56 AM
 * *******************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Web;

namespace Frxs.ServiceCenter.Api.SDK.V20
{
    /// <summary>
    /// SDK�ͻ���HTTP������
    /// </summary>
    internal class HttpWebUtils
    {
        /// <summary>
        /// ִ��HTTP POST����
        /// </summary>
        /// <param name="url">�����ַ</param>
        /// <param name="parameters">�������</param>
        /// <param name="timeout">��ʱʱ��</param>
        /// <returns>HTTP��Ӧ</returns>
        public static HttpRespBody DoPost(string url, IDictionary<string, string> parameters, int timeout)
        {
            HttpWebRequest httpWebRequest = CreateHttpWebRequest(url, "POST", timeout);
            httpWebRequest.ContentType = "application/x-www-form-urlencoded;charset=utf-8";
            byte[] postData = Encoding.UTF8.GetBytes(BuildQuery(parameters));
            Stream reqStream = httpWebRequest.GetRequestStream();
            reqStream.Write(postData, 0, postData.Length);
            reqStream.Close();
            HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            Encoding encoding = Encoding.GetEncoding(httpWebResponse.CharacterSet);
            return HttpWebResponseToString(httpWebResponse, encoding);
        }

        /// <summary>
        /// ִ��HTTP GET����
        /// </summary>
        /// <param name="url">�����ַ</param>
        /// <param name="parameters">�������</param>
        /// <param name="timeout">��ʱʱ��</param>
        /// <returns>HTTP��Ӧ</returns>
        public static HttpRespBody DoGet(string url, IDictionary<string, string> parameters, int timeout)
        {
            if (parameters != null && parameters.Count > 0)
            {
                if (url.Contains("?"))
                {
                    url = url + "&" + BuildQuery(parameters);
                }
                else
                {
                    url = url + "?" + BuildQuery(parameters);
                }
            }
            HttpWebRequest httpWebRequest = CreateHttpWebRequest(url, "GET", timeout);
            httpWebRequest.ContentType = "application/x-www-form-urlencoded;charset=utf-8";
            HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            Encoding encoding = Encoding.GetEncoding(httpWebResponse.CharacterSet);
            return HttpWebResponseToString(httpWebResponse, encoding);
        }

        /// <summary>
        /// ����HttpWebRequest
        /// </summary>
        /// <param name="url">�����ַ</param>
        /// <param name="method">POST/GET</param>
        /// <param name="timeout">��ʱʱ��</param>
        /// <returns></returns>
        private static HttpWebRequest CreateHttpWebRequest(string url, string method, int timeout)
        {
            HttpWebRequest httpWebRequest = (HttpWebRequest)System.Net.WebRequest.Create(url);
            httpWebRequest.ServicePoint.Expect100Continue = false;
            httpWebRequest.Method = method;
            httpWebRequest.KeepAlive = true;
            httpWebRequest.UserAgent = "User-Agent: FRXS";
            httpWebRequest.Referer = "";
            httpWebRequest.Timeout = timeout;
            return httpWebRequest;
        }

        /// <summary>
        /// ����Ӧ��ת��Ϊ�ı���
        /// </summary>
        /// <param name="httpResponse">��Ӧ������</param>
        /// <param name="encoding">���뷽ʽ</param>
        /// <returns>��Ӧ�ı�</returns>
        private static HttpRespBody HttpWebResponseToString(HttpWebResponse httpResponse, Encoding encoding)
        {
            Stream stream = null;
            StreamReader reader = null;
            try
            {
                //���ַ����ķ�ʽ��ȡHTTP��Ӧ
                stream = httpResponse.GetResponseStream();
                reader = new StreamReader(stream, encoding);
                string body = reader.ReadToEnd();
                //�����µ��������
                HttpRespBody respBody = new HttpRespBody(body);
                //����һ��http״̬��
                respBody.Headers.Add("StatusCode", httpResponse.StatusCode.ToString());
                //��httpHeader���ϱ��浽�������
                httpResponse.Headers.AllKeys.ToList().ForEach(key =>
                {
                    if (!respBody.Headers.ContainsKey(key))
                    {
                        respBody.Headers.Add(key, httpResponse.Headers[key]);
                    }
                });
                return respBody;
            }
            finally
            {
                // �ͷ���Դ
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (httpResponse != null) httpResponse.Close();
            }
        }

        /// <summary>
        /// ��װGET����URL��
        /// </summary>
        /// <param name="url">�����ַ</param>
        /// <param name="parameters">�������</param>
        /// <returns>��������GET����URL</returns>
        private static string BuildGetUrl(string url, IDictionary<string, string> parameters)
        {
            if (parameters != null && parameters.Count > 0)
            {
                if (url.Contains("?"))
                {
                    url = url + "&" + BuildQuery(parameters);
                }
                else
                {
                    url = url + "?" + BuildQuery(parameters);
                }
            }
            return url;
        }

        /// <summary>
        /// ��װ��ͨ�ı����������
        /// </summary>
        /// <param name="parameters">Key-Value��ʽ��������ֵ�</param>
        /// <returns>URL��������������</returns>
        private static string BuildQuery(IDictionary<string, string> parameters)
        {
            StringBuilder postData = new StringBuilder();
            bool hasParam = false;
            IEnumerator<KeyValuePair<string, string>> dem = parameters.GetEnumerator();
            while (dem.MoveNext())
            {
                string name = dem.Current.Key;
                string value = dem.Current.Value;
                // ���Բ����������ֵΪ�յĲ���
                if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(value))
                {
                    if (hasParam)
                    {
                        postData.Append("&");
                    }

                    postData.Append(name);
                    postData.Append("=");
                    postData.Append(HttpUtility.UrlEncode(value));
                    hasParam = true;
                }
            }

            return postData.ToString();
        }
    }
}
