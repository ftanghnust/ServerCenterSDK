/*********************************************************
 * FRXS(ISC) zhangliang@frxs.com 11/2/2015 8:32:16 PM
 * *******************************************************/
using System;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Frxs.ServiceCenter.Api.SDK.V20
{
    /// <summary>
    /// Ĭ����־���
    /// </summary>
    internal class DefaultApiLogger : IApiLogger
    {
        /// <summary>
        /// 
        /// </summary>
        public const string LOG_FILE_NAME = "FRXS_ERR_SDK_{0}.log";
        public const string DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

        /// <summary>
        /// 
        /// </summary>
        static DefaultApiLogger()
        {
            string logFilePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, 
                string.Format(LOG_FILE_NAME, DateTime.Now.ToString("yyyyMMdd")));
            Trace.Listeners.Add(new TextWriterTraceListener(logFilePath));
            Trace.AutoFlush = true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public void Error(string message)
        {
            Trace.WriteLine(message, DateTime.Now.ToString(DATETIME_FORMAT) + " ERROR");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public void Warn(string message)
        {
            Trace.WriteLine(message, DateTime.Now.ToString(DATETIME_FORMAT) + " WARN");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public void Info(string message)
        {
            Trace.WriteLine(message, DateTime.Now.ToString(DATETIME_FORMAT) + " INFO");
        }
    }
}
